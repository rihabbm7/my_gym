#include <gtk/gtk.h>
typedef struct date
{
	int jour;
	int mois;
	int annees;

}date;


typedef struct admin 
{
	char nom[30];	
	char prenom[30];
	char num[30];
	char login[30];
	char password[30];
}admin;
typedef struct adherent 
{
	char nom[30];	
	char prenom[30];
	char date_ne[30];
	date dtn;
	char num[30];
	char sexe[30];
	char type_dabo[30];
	char payemant[30];
	char login[30];
	char password[30];
	int role;
}adherent;
typedef struct coach
{
	char nom[30];
	char prenom[30];
	char date_ne[30];
	date dtn;
	char sexe[30];
	char specialite[30];
	char login[30];
	char password[30];
	int role;
	
}coach;
typedef struct medecin 
{
	char nom[30];
	char prenom[30];
	char date_ne[30];
	date dtn;
	char sexe[30];
	char login[30];
	char password[30];
	int role;
}medecin;
typedef struct  kine
{
	char nom[30];
	char prenom[30];
	char date_ne[30];
	date dtn;
	char sexe[30];
	char login[30];
	char password[30];
	int role;
}kine;
typedef struct  dieteticien 
{
	char nom[30];
	char prenom[30];
	char date_ne[30];
	date datn;
	char sexe[30];
	char login[30];
	char password[30];
	int role;
}dieteticien;
typedef struct user
{
	char login[30];
	char password[30];
	char role[30];

}user;
typedef struct fihe_med
{
	char historique[100];
	char probleme[100];
	char taill[10];
	char poids[10];
	char imc[10];
	char medica[100];
	char autre[100];
	adherent a;
	
}fihe_med;

typedef struct  dispo 
{
	char nom[30];
	char prenom[30];
	int role;
	date dtn;	
	char date_ds[30];
	char horaire[30];



} dispo1 ;
typedef struct rendez_vous
{
	char nom[30];
	char prenom[30];
	char nom1[30];
	char prenom1[30];
	char date[50];



}rdv1 ;
typedef struct event
{
	char titre[200];
	date dtn;
	char description[500];
} event ;

int verifier(char login[50],char passe[50]);

void ajouter_det(dieteticien d1);
void ajouter_med(medecin m);
void ajouter_kine(kine k);
void ajouter_coach(coach c);
void ajouter_adh(adherent h);
void ajouter_fiche_med(fihe_med fi);
void ajouter_eve(event e);

void afficher_staff(GtkWidget *liste);
void afficher_adh(GtkWidget *liste);
void afficher_coach(GtkWidget *liste);
void afficher_diet(GtkWidget *liste);
void afficher_kine(GtkWidget *liste);
void afficher_med(GtkWidget *liste);


void modifier_med(char nlogin[],char npassword[],char login[],char password[]);
void modifier_diet(char nlogin[],char npassword[],char login[],char password[]);
void modifier_kine(char nlogin[],char npassword[],char login[],char password[]);
void modifier_admin(char nlogin[],char npassword[],char login[],char password[]);
void modifier_adh(char nlogin[],char npassword[],char login[],char password[]);
void modifier_coach(char nlogin[],char npassword[],char login[],char password[]);

void sup_med(gchar *name5,gchar *prenom5  );
void modifier2_med(medecin m,gchar *name5,gchar *prenom5 );

void sup_adh(gchar *name1,gchar *prenom1  );
void modifier2_adh(adherent h,gchar *name1,gchar *prenom1 );

void sup_kine(gchar *name1,gchar *prenom1  );
void modifier2_kine(kine h,gchar *name1,gchar *prenom1 );

void sup_diet(gchar *name1,gchar *prenom1  );
void modifier2_diet(dieteticien h,gchar *name1,gchar *prenom1 );

void sup_coach(gchar *name1,gchar *prenom1);
void modifier2_coach(coach h,gchar *name1,gchar *prenom1 );

void sup_fi_med(gchar *name1,gchar *prenom1);
void modifier2_fich_med(fihe_med h,gchar *name1,gchar *prenom1 );

void ajout_dispo_med(dispo1 ds,user u);
void ajout_dispo_diet(dispo1 ds,user u);
void ajout_dispo_coach(dispo1 ds,user u);
void ajout_dispo_kine(dispo1 ds,user u);





	
	

