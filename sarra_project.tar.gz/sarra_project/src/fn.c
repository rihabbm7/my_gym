
#include <string.h>
#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fn.h" 



int verifier(char login[50],char passe[50])
{

FILE*f;
char login1[50];
char passe1[50];
int role1;
int v1=3,v2=3,r=-1;

f=fopen("user.txt","r");

while(fscanf(f,"%s %s %d\n",login1,passe1,&role1)!=EOF)
{
if(v1!=0){ v1=strcmp(login,login1);
	 if(v1==0){v2=strcmp(passe,passe1);
		 if(v2==0){r=role1;  }}}
}
fclose(f);
return r;
}

void ajouter_det(dieteticien d1)
{
FILE*f;
FILE*f6;

f6=fopen("dieteticien.txt","a");
fprintf(f6,"%s %s %d/%d/%d %s %s %s %d\n",d1.nom,d1.prenom,d1.datn.jour,d1.datn.mois,d1.datn.annees,d1.sexe,d1.login,d1.password,d1.role);
fclose(f6);
f=fopen("user.txt","a");
fprintf(f,"%s %s %d\n",d1.login,d1.password,d1.role);
fclose(f);
}

void ajouter_med(medecin m)
{
FILE*f;
FILE*f4;

f4=fopen("medecin.txt","a");
fprintf(f4,"%s %s %d/%d/%d %s %s %s %d\n",m.nom,m.prenom,m.dtn.jour,m.dtn.mois,m.dtn.annees,m.sexe,m.login,m.password,m.role);
fclose(f4);
f=fopen("user.txt","a");
fprintf(f,"%s %s %d\n",m.login,m.password,m.role);
fclose(f);
}

void ajouter_kine(kine k)
{
FILE*f;
FILE*f5;

f5=fopen("kine.txt","a");
fprintf(f5,"%s %s %d/%d/%d %s %s %s %d\n",k.nom,k.prenom,k.dtn.jour,k.dtn.mois,k.dtn.annees,k.sexe,k.login,k.password,k.role);
fclose(f5);
f=fopen("user.txt","a");
fprintf(f,"%s %s %d\n",k.login,k.password,k.role);
fclose(f);
}


void ajouter_coach(coach c)
{
FILE*f;
FILE*f3;

f3=fopen("coach.txt","a");
fprintf(f3,"%s %s %d/%d/%d %s %s %s %s %d\n",c.nom,c.prenom,c.dtn.jour,c.dtn.mois,c.dtn.annees,c.sexe,c.specialite,c.login,c.password,c.role);
fclose(f3);
f=fopen("user.txt","a");
fprintf(f,"%s %s %d\n",c.login,c.password,c.role);
fclose(f);
}
void ajouter_adh(adherent h)
{
FILE*f;
FILE*f1;

f1=fopen("adherent.txt","a");
fprintf(f1,"%s %s %s %d/%d/%d %s %s %s %s %s %d\n",h.nom,h.prenom,h.num,h.dtn.jour,h.dtn.mois,h.dtn.annees,h.sexe,h.type_dabo,h.payemant,h.login,h.password,h.role);
fclose(f1);
f=fopen("user.txt","a");
fprintf(f,"%s %s %d\n",h.login,h.password,h.role);
fclose(f);

}

void ajouter_fiche_med(fihe_med fi)
{

FILE*f7;

f7=fopen("fiche_med.txt","a");
fprintf(f7,"%s %s %d/%d/%d %s %s %s %s %s %s %s %s \n",fi.a.nom,fi.a.prenom,fi.a.dtn.jour,fi.a.dtn.mois,fi.a.dtn.annees,fi.a.sexe,fi.taill,fi.poids,fi.imc,fi.historique,fi.probleme,fi.medica,fi.autre);
fclose(f7);
}
void ajouter_eve(event e)

{
	//event e;
FILE*fd1;
	
fd1=fopen("evee.txt","a");
fprintf(fd1,"%s %d/%d/%d %s\n",e.titre,e.dtn.jour,e.dtn.mois,e.dtn.annees,e.description);
fclose(fd1);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	NOM,
	PRENOM,
	DATE,
	SEXE,				//affichage staff
	ROLE,
	COLUMNS

};
void afficher_staff(GtkWidget *liste)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;	
GtkTreeIter iter;
GtkListStore *store;
coach c;
medecin m; 
kine k;
dieteticien d;

store=NULL;
FILE*f;

store=gtk_tree_view_get_model(liste);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" DATE",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" role",renderer,"text",ROLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT);

f=fopen("coach.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %d\n",c.nom,c.prenom,c.date_ne,c.sexe,c.specialite,c.login,c.password,&c.role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,c.nom,PRENOM,c.prenom,DATE,c.date_ne,SEXE,c.sexe,ROLE,c.role,-1);
}
fclose(f);

f=fopen("medecin.txt","r");
while(fscanf(f,"%s %s %s  %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,m.nom,PRENOM,m.prenom,DATE,m.date_ne,SEXE,m.sexe,ROLE,m.role,-1);
}
fclose(f);

f=fopen("kine.txt","r");
while(fscanf(f,"%s %s %s  %s %s %s %d\n",k.nom,k.prenom,k.date_ne,k.sexe,k.login,k.password,&k.role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,k.nom,PRENOM,k.prenom,DATE,k.date_ne,SEXE,k.sexe,ROLE,k.role,-1);
}
fclose(f);
f=fopen("dieteticien.txt","r");
while(fscanf(f,"%s %s %s  %s %s %s %d\n",d.nom,d.prenom,d.date_ne,d.sexe,d.login,d.password,&d.role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,d.nom,PRENOM,d.prenom,DATE,d.date_ne,SEXE,d.sexe,ROLE,d.role,-1);
}
fclose(f);




gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	NOM1,
	PRENOM1,
	SEXE1,
	TYPE1,
	PAYEMANT1,			//affichage treeview adherent
	DATE1,
	COLUMNS1

};

void afficher_adh(GtkWidget *liste)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

adherent a;

store=NULL;
FILE*f;

store=gtk_tree_view_get_model(liste);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Prenom",renderer,"text",PRENOM1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" sexe",renderer,"text",SEXE1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type d'abonnement ",renderer,"text",TYPE1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Payemant",renderer,"text",PAYEMANT1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("adherent.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.num,a.date_ne,a.sexe,a.type_dabo,a.payemant,a.login,a.password,&a.role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM1,a.nom,PRENOM1,a.prenom,DATE1,a.date_ne,SEXE1,a.sexe,TYPE1,a.type_dabo,PAYEMANT1,a.payemant,-1);
}
fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	NOM2,
	PRENOM2,    //affichage treeview coach
	SEXE2,
	DATE2,
	SPECIALITE2,
	COLUMNS2

};
void afficher_coach(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

coach c;

store=NULL;
FILE*f;

store=gtk_tree_view_get_model(liste);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM2,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Prenom",renderer,"text",PRENOM2,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" sexe",renderer,"text",SEXE2,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE2,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" specialite",renderer,"text",SPECIALITE2,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


store=gtk_list_store_new(COLUMNS2,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("coach.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %d\n",c.nom,c.prenom,c.date_ne,c.sexe,c.specialite,c.login,c.password,&c.role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM2,c.nom,PRENOM2,c.prenom,DATE2,c.date_ne,SEXE2,c.sexe,SPECIALITE2,c.specialite,-1);
}
fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	NOM3,
	PRENOM3,
	SEXE3,				//afichage treeview diet
	DATE3,
	COLUMNS3

};
void afficher_diet(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

dieteticien d;

store=NULL;
FILE*f;

store=gtk_tree_view_get_model(liste);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM3,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Prenom",renderer,"text",PRENOM3,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" sexe",renderer,"text",SEXE3,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE3,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



store=gtk_list_store_new(COLUMNS3,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("dieteticien.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %d\n",d.nom,d.prenom,d.date_ne,d.sexe,d.login,d.password,&d.role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM3,d.nom,PRENOM3,d.prenom,DATE3,d.date_ne,SEXE3,d.sexe,-1);
}
fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	NOM4,
	PRENOM4,
	SEXE4,				//affichage treeview kine
	DATE4,
	COLUMNS4

};
void afficher_kine(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

kine k;

store=NULL;
FILE*f;

store=gtk_tree_view_get_model(liste);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM4,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Prenom",renderer,"text",PRENOM4,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" sexe",renderer,"text",SEXE4,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE4,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



store=gtk_list_store_new(COLUMNS4,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("kine.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %d\n",k.nom,k.prenom,k.date_ne,k.sexe,k.login,k.password,&k.role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM4,k.nom,PRENOM4,k.prenom,DATE4,k.date_ne,SEXE4,k.sexe,-1);
}
fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	NOM5,
	PRENOM5,
	SEXE5,			//affichage treeview medicin 
	DATE5,
	COLUMNS5

};
void afficher_med(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

medecin m;

store=NULL;
FILE*f;

store=gtk_tree_view_get_model(liste);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM5,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Prenom",renderer,"text",PRENOM5,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" sexe",renderer,"text",SEXE5,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE5,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



store=gtk_list_store_new(COLUMNS5,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("medecin.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM5,m.nom,PRENOM5,m.prenom,DATE5,m.date_ne,SEXE5,m.sexe,-1);
}
fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

enum
{
	NOM6,
	PRENOM6,
	SEXE6,						//affichage treeview fiche medicale
	DATE6,
	COLUMNS6

};
void afficher_fi_med(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

fihe_med fi;

store=NULL;
FILE*f;

store=gtk_tree_view_get_model(liste);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM6,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Prenom",renderer,"text",PRENOM6,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" sexe",renderer,"text",SEXE6,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE6,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS6,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("fiche_med.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s\n",fi.a.nom,fi.a.prenom,fi.a.date_ne,fi.a.sexe,
fi.taill,fi.poids,fi.imc,fi.historique,fi.probleme,fi.medica,fi.autre)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM6,fi.a.nom,PRENOM6,fi.a.prenom,DATE6,fi.a.date_ne,SEXE6,fi.a.sexe,-1);
}
fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void modifier_med(char nlogin[],char npassword[],char login[],char password[])
{
FILE*f1;
FILE*f2;

FILE*f3;		//modifier login et mot de passe medicin depuis usr medicin
FILE*f4;

medecin m;
user u;

f1=fopen("medecin.txt","r");
f2=fopen("medecin1.txt","w");

while(fscanf(f1,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{     
    if(strcmp(m.login,login)!=0 && strcmp(m.password,password)!=0){
      fprintf(f2,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);
								    }
  if(strcmp(m.login,login)==0 && strcmp(m.password,password)==0){
      fprintf(f2,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,nlogin,npassword,m.role);
								    }	
}
fclose(f1);
fclose(f2);

f4=fopen("user1.txt","w");
f3=fopen("user.txt","r");

while(fscanf(f3,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,login)!=0 && strcmp(u.password,password)!=0){
        fprintf(f4,"%s %s %s\n",u.login,u.password,u.role);
								    }
    	if(strcmp(u.login,login)==0 && strcmp(u.password,password)==0){
	fprintf(f4,"%s %s %s\n",nlogin,npassword,u.role);
								    }	
}
fclose(f4);
fclose(f3);

f4=fopen("user1.txt","r");
f3=fopen("user.txt","w");

f2=fopen("medecin1.txt","r");
f1=fopen("medecin.txt","w");

while(fscanf(f2,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);
}
while(fscanf(f4,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f3,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f1);
fclose(f2);
fclose(f3);
fclose(f4);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

void modifier_diet(char nlogin[],char npassword[],char login[],char password[])
{
FILE*f1;
FILE*f2;
				//modifier login et mot de passe diet depuis diet 
FILE*f3;
FILE*f4;

dieteticien d;
user u;

f1=fopen("dieteticien.txt","r");
f2=fopen("dieteticien1.txt","w");

while(fscanf(f1,"%s %s %s %s %s %s %d\n",d.nom,d.prenom,d.date_ne,d.sexe,d.login,d.password,&d.role)!=EOF)
{     
    if(strcmp(d.login,login)!=0 && strcmp(d.password,password)!=0){
      fprintf(f2,"%s %s %s %s %s %s %d\n",d.nom,d.prenom,d.date_ne,d.sexe,d.login,d.password,d.role);
								    }
  if(strcmp(d.login,login)==0 && strcmp(d.password,password)==0){
      fprintf(f2,"%s %s %s %s %s %s %d\n",d.nom,d.prenom,d.date_ne,d.sexe,nlogin,npassword,d.role);
								    }	
}
fclose(f1);
fclose(f2);

f4=fopen("user1.txt","w");
f3=fopen("user.txt","r");

while(fscanf(f3,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,login)!=0 && strcmp(u.password,password)!=0){
        fprintf(f4,"%s %s %s\n",u.login,u.password,u.role);
								    }
    	if(strcmp(u.login,login)==0 && strcmp(u.password,password)==0){
	fprintf(f4,"%s %s %s\n",nlogin,npassword,u.role);
								    }	
}
fclose(f4);
fclose(f3);

f4=fopen("user1.txt","r");
f3=fopen("user.txt","w");

f2=fopen("dieteticien1.txt","r");
f1=fopen("dieteticien.txt","w");

while(fscanf(f2,"%s %s %s %s %s %s %d\n",d.nom,d.prenom,d.date_ne,d.sexe,d.login,d.password,&d.role)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s %s %d\n",d.nom,d.prenom,d.date_ne,d.sexe,d.login,d.password,d.role);
}
while(fscanf(f4,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f3,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f1);
fclose(f2);
fclose(f3);
fclose(f4);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void modifier_kine(char nlogin[],char npassword[],char login[],char password[])
{
FILE*f1;
FILE*f2;

FILE*f3;		//modifier login et mot de passe kine depuis usr kine 
FILE*f4;

kine k;
user u;

f1=fopen("kine.txt","r");
f2=fopen("kine1.txt","w");

while(fscanf(f1,"%s %s %s %s %s %s %d\n",k.nom,k.prenom,k.date_ne,k.sexe,k.login,k.password,&k.role)!=EOF)
{     
    if(strcmp(k.login,login)!=0 && strcmp(k.password,password)!=0){
      fprintf(f2,"%s %s %s %s %s %s %d\n",k.nom,k.prenom,k.date_ne,k.sexe,k.login,k.password,k.role);
								    }
  if(strcmp(k.login,login)==0 && strcmp(k.password,password)==0){
      fprintf(f2,"%s %s %s %s %s %s %d\n",k.nom,k.prenom,k.date_ne,k.sexe,nlogin,npassword,k.role);
								    }	
}
fclose(f1);
fclose(f2);

f4=fopen("user1.txt","w");
f3=fopen("user.txt","r");

while(fscanf(f3,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,login)!=0 && strcmp(u.password,password)!=0){
        fprintf(f4,"%s %s %s\n",u.login,u.password,u.role);
								    }
    	if(strcmp(u.login,login)==0 && strcmp(u.password,password)==0){
	fprintf(f4,"%s %s %s\n",nlogin,npassword,u.role);
								    }	
}
fclose(f4);
fclose(f3);

f4=fopen("user1.txt","r");
f3=fopen("user.txt","w");

f2=fopen("kine1.txt","r");
f1=fopen("kine.txt","w");

while(fscanf(f2,"%s %s %s %s %s %s %d\n",k.nom,k.prenom,k.date_ne,k.sexe,k.login,k.password,&k.role)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s %s %d\n",k.nom,k.prenom,k.date_ne,k.sexe,k.login,k.password,k.role);
}
while(fscanf(f4,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f3,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f1);
fclose(f2);
fclose(f3);
fclose(f4);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void modifier_admin(char nlogin[],char npassword[],char login[],char password[])
{

FILE*f1;
FILE*f2;
FILE*f3;
FILE*f4;
				//modifier login et mot de passe admin depuis admin
admin k;
user u;

f1=fopen("admin.txt","r");
f2=fopen("admin1.txt","w");

while(fscanf(f1,"%s %s %s %s %s\n",k.nom,k.prenom,k.num,k.login,k.password)!=EOF)
{     
    if(strcmp(k.login,login)!=0 && strcmp(k.password,password)!=0){
      fprintf(f2,"%s %s %s %s %s\n",k.nom,k.prenom,k.num,k.login,k.password);
								    }
  if(strcmp(k.login,login)==0 && strcmp(k.password,password)==0){
      fprintf(f2,"%s %s %s %s %s\n",k.nom,k.prenom,k.num,nlogin,npassword);
								    }	
}
fclose(f1);
fclose(f2);

f4=fopen("user1.txt","w");
f3=fopen("user.txt","r");

while(fscanf(f3,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,login)!=0 && strcmp(u.password,password)!=0){
        fprintf(f4,"%s %s %s\n",u.login,u.password,u.role);
								    }
    	if(strcmp(u.login,login)==0 && strcmp(u.password,password)==0){
	fprintf(f4,"%s %s %s\n",nlogin,npassword,u.role);
								    }	
}
fclose(f4);
fclose(f3);

f4=fopen("user1.txt","r");
f3=fopen("user.txt","w");

f2=fopen("admin1.txt","r");
f1=fopen("admin.txt","w");

while(fscanf(f2,"%s %s %s %s %s\n",k.nom,k.prenom,k.num,k.login,k.password)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s\n",k.nom,k.prenom,k.num,k.login,k.password);
}
while(fscanf(f4,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f3,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f1);
fclose(f2);
fclose(f3);
fclose(f4);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
void modifier_adh(char nlogin[],char npassword[],char login[],char password[])
{
FILE*f1;
FILE*f2;
FILE*f3;
FILE*f4;			//modifier login et mot de passe adherant depuis un usr adherant 

adherent ad;
user u;

f1=fopen("adherent.txt","r");
f2=fopen("adherent1.txt","w");

while(fscanf(f1,"%s %s %s %s %s %s %s %s %s %d\n",ad.nom,ad.prenom,ad.num,ad.date_ne,ad.sexe,ad.type_dabo,ad.payemant,ad.login,ad.password,&ad.role)!=EOF)
{     
    if(strcmp(ad.login,login)!=0 && strcmp(ad.password,password)!=0){
      fprintf(f2,"%s %s %s %s %s %s %s %s %s %d\n",ad.nom,ad.prenom,ad.num,ad.date_ne,ad.sexe,ad.type_dabo,ad.payemant,ad.login,ad.password,ad.role);
								    }
  if(strcmp(ad.login,login)==0 && strcmp(ad.password,password)==0){
      fprintf(f2,"%s %s %s %s %s %s %s %s %s %d\n",ad.nom,ad.prenom,ad.num,ad.date_ne,ad.sexe,ad.type_dabo,ad.payemant,nlogin,npassword,ad.role);
								    }	
}
fclose(f1);
fclose(f2);

f4=fopen("user1.txt","w");
f3=fopen("user.txt","r");

while(fscanf(f3,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,login)!=0 && strcmp(u.password,password)!=0){
        fprintf(f4,"%s %s %s\n",u.login,u.password,u.role);
								    }
    	if(strcmp(u.login,login)==0 && strcmp(u.password,password)==0){
	fprintf(f4,"%s %s %s\n",nlogin,npassword,u.role);
								    }	
}
fclose(f4);
fclose(f3);

f4=fopen("user1.txt","r");
f3=fopen("user.txt","w");

f2=fopen("adherent1.txt","r");
f1=fopen("adherent.txt","w");

while(fscanf(f2,"%s %s %s %s %s %s %s %s %s %d\n",ad.nom,ad.prenom,ad.num,ad.date_ne,ad.sexe,ad.type_dabo,ad.payemant,ad.login,ad.password,&ad.role)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s %s %s %s %s %d\n",ad.nom,ad.prenom,ad.num,ad.date_ne,ad.sexe,ad.type_dabo,ad.payemant,ad.login,ad.password,ad.role);
}
while(fscanf(f4,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f3,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f1);
fclose(f2);
fclose(f3);
fclose(f4);

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void modifier_coach(char nlogin[],char npassword[],char login[],char password[])
{

FILE*f1;
FILE*f2;
			//modifier login et mot de passe  coach depus usr coach
FILE*f3;
FILE*f4;

coach c;
user u;

f1=fopen("coach.txt","r");
f2=fopen("coach1.txt","w");

while(fscanf(f1,"%s %s %s %s %s %s %s %d\n",c.nom,c.prenom,c.date_ne,c.sexe,c.specialite,c.login,c.password,&c.role)!=EOF)
{     
    if(strcmp(c.login,login)!=0 && strcmp(c.password,password)!=0){
      fprintf(f2,"%s %s %s %s %s %s %s %d\n",c.nom,c.prenom,c.date_ne,c.sexe,c.specialite,c.login,c.password,c.role);
								    }
  if(strcmp(c.login,login)==0 && strcmp(c.password,password)==0){
      fprintf(f2,"%s %s %s %s %s %s %s %d\n",c.nom,c.prenom,c.date_ne,c.sexe,c.specialite,nlogin,npassword,c.role);
								    }	
}
fclose(f1);
fclose(f2);

f4=fopen("user1.txt","w");
f3=fopen("user.txt","r");

while(fscanf(f3,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,login)!=0 && strcmp(u.password,password)!=0){
        fprintf(f4,"%s %s %s\n",u.login,u.password,u.role);
								    }
    	if(strcmp(u.login,login)==0 && strcmp(u.password,password)==0){
	fprintf(f4,"%s %s %s\n",nlogin,npassword,u.role);
								    }	
}
fclose(f4);
fclose(f3);

f4=fopen("user1.txt","r");
f3=fopen("user.txt","w");

f2=fopen("coach1.txt","r");
f1=fopen("coach.txt","w");

while(fscanf(f2,"%s %s %s %s %s %s %s %d\n",c.nom,c.prenom,c.date_ne,c.sexe,c.specialite,c.login,c.password,&c.role)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s %s %s %d\n",c.nom,c.prenom,c.date_ne,c.sexe,c.specialite,c.login,c.password,c.role);
}
while(fscanf(f4,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f3,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f1);
fclose(f2);
fclose(f3);
fclose(f4);


}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void sup_med(gchar *name5,gchar *prenom5  ) //supprimer medicin
{

FILE*f4;
FILE*ff4;
FILE*f;				//supprimer un medicin depuis admin
FILE*ff;
medecin m;
user u;
char id[20];
char pass[20];
f4=fopen("medecin.txt","r");
ff4=fopen("medecin1.txt","w");

while(fscanf(f4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{     
    if(strcmp(m.nom,name5)!=0 && strcmp(m.prenom,prenom5)!=0){
      fprintf(ff4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);}
    if(strcmp(m.nom,name5)==0 && strcmp(m.prenom,prenom5)==0){strcpy(id,m.login); strcpy(pass,m.password);}
}	
fclose(f4);
fclose(ff4);

ff=fopen("user1.txt","w");
f=fopen("user.txt","r");

while(fscanf(f,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,id)!=0){
        fprintf(ff,"%s %s %s\n",u.login,u.password,u.role);  }
	
}
fclose(ff);
fclose(f);

ff=fopen("user1.txt","r");
f=fopen("user.txt","w");

ff4=fopen("medecin1.txt","r");
f4=fopen("medecin.txt","w");

while(fscanf(ff4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{
      fprintf(f4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);
}
while(fscanf(ff,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f);
fclose(ff);
fclose(f4);
fclose(ff4);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void modifier2_med(medecin m1,gchar *name5,gchar *prenom5 ) 
{


FILE*f1;
FILE*f2;
				//modifir coordonées medicin depuis admin
FILE*f3;
FILE*f4;

medecin m;
user u;
char id[20];
char pass[20];


f1=fopen("medecin.txt","r");
f2=fopen("medecin1.txt","w");

while(fscanf(f1,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{     
    if(strcmp(m.nom,name5)!=0 && strcmp(m.prenom,prenom5)!=0){
      fprintf(f2,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);
								    }
  if(strcmp(m.nom,name5)==0 && strcmp(m.prenom,prenom5)==0){
      fprintf(f2,"%s %s %d/%d/%d %s %s %s %d\n",m1.nom,m1.prenom,m1.dtn.jour,m1.dtn.mois,m1.dtn.annees,m1.sexe,m1.login,m1.password,m1.role);
				strcpy(id,m.login);strcpy(pass,m.password);	
							    }	
}
fclose(f1);
fclose(f2);

f4=fopen("user1.txt","w");
f3=fopen("user.txt","r");

while(fscanf(f3,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,id)!=0 && strcmp(u.password,pass)!=0){
        fprintf(f4,"%s %s %s\n",u.login,u.password,u.role);
								    }
    	if(strcmp(u.login,id)==0 && strcmp(u.password,pass)==0){
	fprintf(f4,"%s %s %s\n",m1.login,m1.password,u.role);
								    }	
}
fclose(f4);
fclose(f3);


f4=fopen("user1.txt","r");
f3=fopen("user.txt","w");

f2=fopen("medecin1.txt","r");
f1=fopen("medecin.txt","w");

while(fscanf(f2,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);
}
while(fscanf(f4,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f3,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f1);
fclose(f2);
fclose(f3);
fclose(f4);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
void sup_kine(gchar *name5,gchar *prenom5  ) //supprimer kine
{

FILE*f4;
FILE*ff4;
FILE*f;				//supprimer un kine depuis admin
FILE*ff;
kine m;
user u;
char id[20];
char pass[20];
f4=fopen("kine.txt","r");
ff4=fopen("kine1.txt","w");

while(fscanf(f4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{     
    if(strcmp(m.nom,name5)!=0 && strcmp(m.prenom,prenom5)!=0){
      fprintf(ff4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);}
    if(strcmp(m.nom,name5)==0 && strcmp(m.prenom,prenom5)==0){strcpy(id,m.login); strcpy(pass,m.password);}
}	
fclose(f4);
fclose(ff4);

ff=fopen("user1.txt","w");
f=fopen("user.txt","r");

while(fscanf(f,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,id)!=0){
        fprintf(ff,"%s %s %s\n",u.login,u.password,u.role);  }
	
}
fclose(ff);
fclose(f);

ff=fopen("user1.txt","r");
f=fopen("user.txt","w");

ff4=fopen("kine1.txt","r");
f4=fopen("kine.txt","w");

while(fscanf(ff4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{
      fprintf(f4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);
}
while(fscanf(ff,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f);
fclose(ff);
fclose(f4);
fclose(ff4);
}
/////////////////////////////////////////////////////////////////////////////////////////////
void modifier2_kine(kine m1,gchar *name5,gchar *prenom5 ) 
{



FILE*f1;
FILE*f2;
				//modifir coordonées kine depuis admin
FILE*f3;
FILE*f4;

kine m;
user u;
char id[20];
char pass[20];


f1=fopen("kine.txt","r");
f2=fopen("kine1.txt","w");

while(fscanf(f1,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{     
    if(strcmp(m.nom,name5)!=0 && strcmp(m.prenom,prenom5)!=0){
      fprintf(f2,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);
								    }
  if(strcmp(m.nom,name5)==0 && strcmp(m.prenom,prenom5)==0){
      fprintf(f2,"%s %s %d/%d/%d %s %s %s %d\n",m1.nom,m1.prenom,m1.dtn.jour,m1.dtn.mois,m1.dtn.annees,m1.sexe,m1.login,m1.password,m1.role);
				strcpy(id,m.login);strcpy(pass,m.password);	
							    }	
}
fclose(f1);
fclose(f2);

f4=fopen("user1.txt","w");
f3=fopen("user.txt","r");

while(fscanf(f3,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,id)!=0 && strcmp(u.password,pass)!=0){
        fprintf(f4,"%s %s %s\n",u.login,u.password,u.role);
								    }
    	if(strcmp(u.login,id)==0 && strcmp(u.password,pass)==0){
	fprintf(f4,"%s %s %s\n",m1.login,m1.password,u.role);
								    }	
}
fclose(f4);
fclose(f3);


f4=fopen("user1.txt","r");
f3=fopen("user.txt","w");

f2=fopen("kine1.txt","r");
f1=fopen("kine.txt","w");

while(fscanf(f2,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);
}
while(fscanf(f4,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f3,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f1);
fclose(f2);
fclose(f3);
fclose(f4);



}
///////////////////////////////////////////////////////////////////////////////////////////////
void sup_diet(gchar *name5,gchar *prenom5  )
{


FILE*f4;
FILE*ff4;
FILE*f;				//supprimer un diet depuis admin
FILE*ff;
dieteticien m;
user u;
char id[20];
char pass[20];
f4=fopen("dieteticien.txt","r");
ff4=fopen("dieteticien1.txt","w");

while(fscanf(f4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{     
    if(strcmp(m.nom,name5)!=0 && strcmp(m.prenom,prenom5)!=0){
      fprintf(ff4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);}
    if(strcmp(m.nom,name5)==0 && strcmp(m.prenom,prenom5)==0){strcpy(id,m.login); strcpy(pass,m.password);}
}	
fclose(f4);
fclose(ff4);

ff=fopen("user1.txt","w");
f=fopen("user.txt","r");

while(fscanf(f,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,id)!=0){
        fprintf(ff,"%s %s %s\n",u.login,u.password,u.role);  }
	
}
fclose(ff);
fclose(f);

ff=fopen("user1.txt","r");
f=fopen("user.txt","w");

ff4=fopen("dieteticien1.txt","r");
f4=fopen("dieteticien.txt","w");

while(fscanf(ff4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{
      fprintf(f4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);
}
while(fscanf(ff,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f);
fclose(ff);
fclose(f4);
fclose(ff4);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////
void modifier2_diet(dieteticien m1,gchar *name5,gchar *prenom5 ) 
{



FILE*f1;
FILE*f2;
				//modifir coordonées diet depuis admin
FILE*f3;
FILE*f4;

dieteticien m;
user u;
char id[20];
char pass[20];


f1=fopen("dieteticien.txt","r");
f2=fopen("dieteticien1.txt","w");

while(fscanf(f1,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{     
    if(strcmp(m.nom,name5)!=0 && strcmp(m.prenom,prenom5)!=0){
      fprintf(f2,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);
								    }
  if(strcmp(m.nom,name5)==0 && strcmp(m.prenom,prenom5)==0){
      fprintf(f2,"%s %s %d/%d/%d %s %s %s %d\n",m1.nom,m1.prenom,m1.datn.jour,m1.datn.mois,m1.datn.annees,m1.sexe,m1.login,m1.password,m1.role);
				strcpy(id,m.login);strcpy(pass,m.password);	
							    }	
}
fclose(f1);
fclose(f2);

f4=fopen("user1.txt","w");
f3=fopen("user.txt","r");

while(fscanf(f3,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,id)!=0 && strcmp(u.password,pass)!=0){
        fprintf(f4,"%s %s %s\n",u.login,u.password,u.role);
								    }
    	if(strcmp(u.login,id)==0 && strcmp(u.password,pass)==0){
	fprintf(f4,"%s %s %s\n",m1.login,m1.password,u.role);
								    }	
}
fclose(f4);
fclose(f3);


f4=fopen("user1.txt","r");
f3=fopen("user.txt","w");

f2=fopen("dieteticien1.txt","r");
f1=fopen("dieteticien.txt","w");

while(fscanf(f2,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,m.role);
}
while(fscanf(f4,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f3,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f1);
fclose(f2);
fclose(f3);
fclose(f4);



}
///////////////////////////////////////////////////////////////////////////////////////////////

void sup_adh(gchar *name1,gchar *prenom1  )
{

FILE*f4;
FILE*ff4;
FILE*f;				//supprimer un adherant depuis admin
FILE*ff;
adherent a;
user u;
char id[20];
char pass[20];
f4=fopen("adherent.txt","r");
ff4=fopen("adherent1.txt","w");

while(fscanf(f4,"%s %s %s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.num,a.date_ne,a.sexe,a.type_dabo,a.payemant,a.login,a.password,&a.role)!=EOF)
{     
    if(strcmp(a.nom,name1)!=0 && strcmp(a.prenom,prenom1)!=0){
    fprintf(ff4,"%s %s %s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.num,a.date_ne,a.sexe,a.type_dabo,a.payemant,a.login,a.password,a.role);}
    if(strcmp(a.nom,name1)==0 && strcmp(a.prenom,prenom1)==0){strcpy(id,a.login); strcpy(pass,a.password);}
}	
fclose(f4);
fclose(ff4);

ff=fopen("user1.txt","w");
f=fopen("user.txt","r");

while(fscanf(f,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,id)!=0){
        fprintf(ff,"%s %s %s\n",u.login,u.password,u.role);  }
	
}
fclose(ff);
fclose(f);

ff=fopen("user1.txt","r");
f=fopen("user.txt","w");

ff4=fopen("adherent1.txt","r");
f4=fopen("adherent.txt","w");

while(fscanf(ff4,"%s %s %s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.num,a.date_ne,a.sexe,a.type_dabo,a.payemant,a.login,a.password,&a.role)!=EOF)
{
      fprintf(f4,"%s %s %s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.num,a.date_ne,a.sexe,a.type_dabo,a.payemant,a.login,a.password,a.role);
}
while(fscanf(ff,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f);
fclose(ff);
fclose(f4);
fclose(ff4);

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void modifier2_adh(adherent h,gchar *name1,gchar *prenom1 )
{

FILE*f1;
FILE*f2;
				//modifir coordonées adherant depuis admin
FILE*f3;
FILE*f4;

adherent a;
user u;
char id[20];
char pass[20];


f1=fopen("adherent.txt","r");
f2=fopen("adherent1.txt","w");

while(fscanf(f1,"%s %s %s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.num,a.date_ne,a.sexe,a.type_dabo,a.payemant,a.login,a.password,&a.role)!=EOF)
{     
    if(strcmp(a.nom,name1)!=0 && strcmp(a.prenom,prenom1)!=0){
      fprintf(f2,"%s %s %s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.num,a.date_ne,a.sexe,a.type_dabo,a.payemant,a.login,a.password,a.role);
								    }
  if(strcmp(a.nom,name1)==0 && strcmp(a.prenom,prenom1)==0){
fprintf(f2,"%s %s %s %d/%d/%d %s %s %s %s %s %d\n",h.nom,h.prenom,h.num,h.dtn.jour,h.dtn.mois,h.dtn.annees,h.sexe,h.type_dabo,h.payemant,h.login,h.password,h.role);
				strcpy(id,a.login);strcpy(pass,a.password);	
							    }	
}
fclose(f1);
fclose(f2);

f4=fopen("user1.txt","w");
f3=fopen("user.txt","r");

while(fscanf(f3,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,id)!=0 && strcmp(u.password,pass)!=0){
        fprintf(f4,"%s %s %s\n",u.login,u.password,u.role);
								    }
    	if(strcmp(u.login,id)==0 && strcmp(u.password,pass)==0){
	fprintf(f4,"%s %s %s\n",h.login,h.password,u.role);
								    }	
}
fclose(f4);
fclose(f3);


f4=fopen("user1.txt","r");
f3=fopen("user.txt","w");

f2=fopen("adherent1.txt","r");
f1=fopen("adherent.txt","w");

while(fscanf(f2,"%s %s %s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.num,a.date_ne,a.sexe,a.type_dabo,a.payemant,a.login,a.password,&a.role)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.num,a.date_ne,a.sexe,a.type_dabo,a.payemant,a.login,a.password,a.role);
}
while(fscanf(f4,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f3,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f1);
fclose(f2);
fclose(f3);
fclose(f4);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void sup_coach(gchar *name2,gchar *prenom2)
{
FILE*f4;
FILE*ff4;
FILE*f;				//supprimer un coach depuis admin
FILE*ff;
coach a;
user u;
char id[20];
char pass[20];
f4=fopen("coach.txt","r");
ff4=fopen("coach1.txt","w");

while(fscanf(f4,"%s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.date_ne,a.sexe,a.specialite,a.login,a.password,&a.role)!=EOF)
{     
    if(strcmp(a.nom,name2)!=0 && strcmp(a.prenom,prenom2)!=0){
    fprintf(ff4,"%s %s  %s %s %s %s %s %d\n",a.nom,a.prenom,a.date_ne,a.sexe,a.specialite,a.login,a.password,a.role);}
    if(strcmp(a.nom,name2)==0 && strcmp(a.prenom,prenom2)==0){strcpy(id,a.login); strcpy(pass,a.password);}
}	
fclose(f4);
fclose(ff4);

ff=fopen("user1.txt","w");
f=fopen("user.txt","r");

while(fscanf(f,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,id)!=0){
        fprintf(ff,"%s %s %s\n",u.login,u.password,u.role);  }
	
}
fclose(ff);
fclose(f);

ff=fopen("user1.txt","r");
f=fopen("user.txt","w");

ff4=fopen("coach1.txt","r");
f4=fopen("coach.txt","w");

while(fscanf(ff4,"%s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.date_ne,a.sexe,a.specialite,a.login,a.password,&a.role)!=EOF)
{
      fprintf(f4,"%s %s %s %s %s %s %s %d\n",a.nom,a.prenom,a.date_ne,a.sexe,a.specialite,a.login,a.password,a.role);
}
while(fscanf(ff,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f);
fclose(ff);
fclose(f4);
fclose(ff4);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void modifier2_coach(coach m1,gchar *name5,gchar *prenom5 )  //mofifier coach 
{


FILE*f1;
FILE*f2;
				//modifir coordonées coach depuis admin
FILE*f3;
FILE*f4;

coach m;
user u;
char id[20];
char pass[20];


f1=fopen("coach.txt","r");
f2=fopen("coach1.txt","w");

while(fscanf(f1,"%s %s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.specialite,m.login,m.password,&m.role)!=EOF)
{     
    if(strcmp(m.nom,name5)!=0 && strcmp(m.prenom,prenom5)!=0){
      fprintf(f2,"%s %s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.specialite,m.login,m.password,m.role);
								    }
  if(strcmp(m.nom,name5)==0 && strcmp(m.prenom,prenom5)==0){
      fprintf(f2,"%s %s %d/%d/%d %s %s %s %s %d\n",m1.nom,m1.prenom,m1.dtn.jour,m1.dtn.mois,m1.dtn.annees,m1.sexe,m1.specialite,m1.login,m1.password,m1.role);
				strcpy(id,m.login);strcpy(pass,m.password);	
							    }	
}
fclose(f1);
fclose(f2);

f4=fopen("user1.txt","w");
f3=fopen("user.txt","r");

while(fscanf(f3,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{     
    	if(strcmp(u.login,id)!=0 && strcmp(u.password,pass)!=0){
        fprintf(f4,"%s %s %s\n",u.login,u.password,u.role);
								    }
    	if(strcmp(u.login,id)==0 && strcmp(u.password,pass)==0){
	fprintf(f4,"%s %s %s\n",m1.login,m1.password,u.role);
								    }	
}
fclose(f4);
fclose(f3);


f4=fopen("user1.txt","r");
f3=fopen("user.txt","w");

f2=fopen("coach1.txt","r");
f1=fopen("coach.txt","w");

while(fscanf(f2,"%s %s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.specialite,m.login,m.password,&m.role)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.specialite,m.login,m.password,m.role);
}
while(fscanf(f4,"%s %s %s\n",u.login,u.password,u.role)!=EOF)
{  
        fprintf(f3,"%s %s %s\n",u.login,u.password,u.role);
}
fclose(f1);
fclose(f2);
fclose(f3);
fclose(f4);



}
///////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void sup_fi_med(gchar *name1,gchar *prenom1)
{
FILE*f4;
FILE*ff4;
FILE*f;				//supprimer une fiche medicale depuis medecin
FILE*ff;
fihe_med m;
user u;
char id[20];
char pass[20];
f4=fopen("fiche_med.txt","r");
ff4=fopen("fiche_med1.txt","w");

while(fscanf(f4,"%s %s %s %s %s %s %s %s %s %s %s\n",m.a.nom,m.a.prenom,m.a.date_ne,m.a.sexe,m.taill,m.poids,m.imc,m.historique,m.probleme,m.medica,m.autre)!=EOF)
{     
    if(strcmp(m.a.nom,name1)!=0 && strcmp(m.a.prenom,prenom1)!=0){
      fprintf(ff4,"%s %s %s %s %s %s %s %s %s %s %s\n",m.a.nom,m.a.prenom,m.a.date_ne,m.a.sexe,m.taill,m.poids,m.imc,m.historique,m.probleme,m.medica,m.autre);}
   
}	
fclose(f4);
fclose(ff4);



ff4=fopen("fiche_med1.txt","r");
f4=fopen("fiche_med.txt","w");

while(fscanf(ff4,"%s %s %s %s %s %s %s %s %s %s %s\n",m.a.nom,m.a.prenom,m.a.date_ne,m.a.sexe,m.taill,m.poids,m.imc,m.historique,m.probleme,m.medica,m.autre)!=EOF)
{
      fprintf(f4,"%s %s %s %s %s %s %s %s %s %s %s\n",m.a.nom,m.a.prenom,m.a.date_ne,m.a.sexe,m.taill,m.poids,m.imc,m.historique,m.probleme,m.medica,m.autre);
}


fclose(f4);
fclose(ff4);

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void modifier2_fich_med(fihe_med m1,gchar *name5,gchar *prenom5)     //modifier fiche medicale
{

FILE*f1;
FILE*f2;
				//modifir fiche medicale depuis medecin
fihe_med m;


f1=fopen("fiche_med.txt","r");
f2=fopen("fiche_med1.txt","w");

while(fscanf(f1,"%s %s %s %s %s %s %s %s %s %s %s\n",m.a.nom,m.a.prenom,m.a.date_ne,m.a.sexe,m.taill,m.poids,m.imc,m.historique,m.probleme,m.medica,m.autre)!=EOF)
{   
    if(strcmp(m.a.nom,name5)!=0 && strcmp(m.a.prenom,prenom5)!=0){
      fprintf(f2,"%s %s %s %s %s %s %s %s %s %s %s\n",m.a.nom,m.a.prenom,m.a.date_ne,m.a.sexe,m.taill,m.poids,m.imc,m.historique,m.probleme,m.medica,m.autre);
								    }	
 if(strcmp(m.a.nom,name5)==0 && strcmp(m.a.prenom,prenom5)==0){
      fprintf(f2,"%s %s %d/%d/%d %s %s %s %s %s %s %s %s\n",m1.a.nom,m1.a.prenom,m1.a.dtn.jour,m1.a.dtn.mois,m1.a.dtn.annees,m1.a.sexe,m1.taill,m1.poids,m1.imc,m1.historique,m1.probleme,m1.medica,m1.autre);}

}
fclose(f1);
fclose(f2);

f2=fopen("fiche_med1.txt","r");
f1=fopen("fiche_med.txt","w");

while(fscanf(f2,"%s %s %s %s %s %s %s %s %s %s %s\n",m.a.nom,m.a.prenom,m.a.date_ne,m.a.sexe,m.taill,m.poids,m.imc,m.historique,m.probleme,m.medica,m.autre)!=EOF)
{
      fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s\n",m.a.nom,m.a.prenom,m.a.date_ne,m.a.sexe,m.taill,m.poids,m.imc,m.historique,m.probleme,m.medica,m.autre);
}
fclose(f1);
fclose(f2);


}
///////////////////////////////////////////////////////////////////////////////////////////////////////

void ajout_dispo_med(dispo1 ds,user u)
{
FILE*f8;
FILE*f4;
medecin m;



f8=fopen("dispo.txt","a");
f4=fopen("medecin.txt","r");
while(fscanf(f4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
	{
	if(strcmp(u.login,m.login)==0 && strcmp(u.password,m.password)==0)
			{
	strcpy(ds.nom,m.nom);
	strcpy(ds.prenom,m.prenom);
	ds.role=m.role;

			}
		}
fprintf(f8,"%s %s %d %d/%d/%d %s\n",ds.nom,ds.prenom,ds.role,ds.dtn.jour,ds.dtn.mois,ds.dtn.annees,ds.horaire);
fclose(f8);
fclose(f4);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
void ajout_dispo_diet(dispo1 ds,user u)
{

FILE*f8;
FILE*f4;
dieteticien m;



f8=fopen("dispo.txt","a");
f4=fopen("dieteticien.txt","r");
while(fscanf(f4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
	{
	if(strcmp(u.login,m.login)==0 && strcmp(u.password,m.password)==0)
			{
	strcpy(ds.nom,m.nom);
	strcpy(ds.prenom,m.prenom);
	ds.role=m.role;

			}
		}
fprintf(f8,"%s %s %d %d/%d/%d %s\n",ds.nom,ds.prenom,ds.role,ds.dtn.jour,ds.dtn.mois,ds.dtn.annees,ds.horaire);
fclose(f8);
fclose(f4);

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ajout_dispo_coach(dispo1 ds,user u)
{FILE*f8;
FILE*f4;
coach m;

f8=fopen("dispo.txt","a");
f4=fopen("coach.txt","r");
while(fscanf(f4,"%s %s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.specialite,m.login,m.password,&m.role)!=EOF)
	{
	if(strcmp(u.login,m.login)==0 && strcmp(u.password,m.password)==0)
			{
	strcpy(ds.nom,m.nom);
	strcpy(ds.prenom,m.prenom);
	ds.role=m.role;

			}
		}
fprintf(f8,"%s %s %d %d/%d/%d %s\n",ds.nom,ds.prenom,ds.role,ds.dtn.jour,ds.dtn.mois,ds.dtn.annees,ds.horaire);
fclose(f8);
fclose(f4);

}
void ajout_dispo_kine(dispo1 ds,user u)
{FILE*f8;
FILE*f4;
kine k;

f8=fopen("dispo.txt","a");
f4=fopen("kine.txt","r");
while(fscanf(f4,"%s %s %s %s %s %s %d\n",k.nom,k.prenom,k.date_ne,k.sexe,k.login,k.password,&k.role)!=EOF)
	{
	if(strcmp(u.login,k.login)==0 && strcmp(u.password,k.password)==0)
			{
	strcpy(ds.nom,k.nom);
	strcpy(ds.prenom,k.prenom);
	ds.role=k.role;

			}
		}
fprintf(f8,"%s %s %d %d/%d/%d %s\n",ds.nom,ds.prenom,ds.role,ds.dtn.jour,ds.dtn.mois,ds.dtn.annees,ds.horaire);
fclose(f8);
fclose(f4);

}









