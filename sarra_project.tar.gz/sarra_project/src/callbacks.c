#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <string.h>
#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fn.h" 


//windows 
  GtkWidget *authentification;
  GtkWidget *Admin;
  GtkWidget *Coach;
  GtkWidget *Medecin;
  GtkWidget *Kin__;
  GtkWidget *Dieteticien;
  GtkWidget *Adh__rent;
  GtkWidget *Ajout_Adh__rent;
  GtkWidget *Ajout_coach;
  GtkWidget *Ajout_medcin;
  GtkWidget *Ajout_kin__;
  GtkWidget *Ajout_dieteticien;
  GtkWidget *fiche_med;
  GtkWidget *fiche_suivi;
  GtkWidget *dispo;
  GtkWidget *window1;
////////////////////////////////////////////////////////////////
GtkWidget *input1;  //u.login
GtkWidget *input2;  //u.password


GtkWidget *output1;

///////////////////////////////////////////////
//file
FILE*f;  /*user*/     		FILE*ff;  //user1      
FILE*f1; /*admin*/    		FILE*ff1; //admin1
FILE*f2; /*adherant*/ 		FILE*ff2; /*adherant1*/                                        
FILE*f3 ;/*coach*/		FILE*ff3 ;/*coach1*/
FILE*f4; /*medecin*/		FILE*ff4; /*medecin1*/
FILE*f5; /*kine*/		FILE*ff5; //kine
FILE*f6; /*dieteticien*/	FILE*ff6; //dieteticien
FILE*f7; /*fiche medical*/	FILE*ff7; //fiche medical
FILE*f8;/*fiche_dispo*/
FILE*f9;/*fiche rendez vous */
FILE*fd1;/*fiche event*/
/////////////////////////////////////////////// 

//struct
user u;
admin a;
adherent ad;
coach c;
medecin m;
kine k;
dieteticien d;
fihe_med fi;
rdv1 rd;
event e;

////////////////////////////////////////////////

int v=-1;
int v1=-1;
int w=0;
int wf=0;


void on_button1_clicked (GtkWidget *obj, gpointer user_data) //login
{


authentification=lookup_widget(obj,"authentification");
input1=lookup_widget(obj,"entry1");
input2=lookup_widget(obj,"entry2");
output1=lookup_widget(obj,"label3");





strcpy(u.login,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(u.password,gtk_entry_get_text(GTK_ENTRY(input2)));

v=verifier(u.login,u.password);



if(v==1)
{
Admin=create_Admin();
gtk_widget_destroy (authentification);
gtk_widget_show (Admin);
}
else if(v==2){
Adh__rent=create_Adh__rent();
gtk_widget_destroy(authentification);
gtk_widget_show(Adh__rent);
}
else if(v==3){
Coach=create_Coach();
gtk_widget_destroy(authentification);
gtk_widget_show(Coach);
}
else if(v==4){
Medecin=create_Medecin();
gtk_widget_destroy(authentification);
gtk_widget_show(Medecin);
}
else if(v==5){
Kin__=create_Kin__();
gtk_widget_destroy(authentification);
gtk_widget_show(Kin__);
}
else if(v==6){
Dieteticien=create_Dieteticien();
gtk_widget_destroy(authentification);
gtk_widget_show(Dieteticien);
}


else { gtk_label_set_text(GTK_LABEL(output1),"verifiez ID ou mot de passe");}

}


void on_logout1_clicked (GtkButton *obj, gpointer user_data)
{
authentification=create_authentification();
gtk_widget_destroy (Admin);
gtk_widget_show (authentification);
v=-1;v1=-1;

}


void on_logout2_clicked (GtkButton *obj, gpointer user_data)
{
authentification=create_authentification();
gtk_widget_destroy(Adh__rent);
gtk_widget_show(authentification);v=-1; v1=-1;
}


void on_logout3_clicked (GtkButton *obj, gpointer user_data)
{
authentification=create_authentification();
gtk_widget_destroy(Coach);
gtk_widget_show(authentification);v=-1;v1=-1;
}


void on_logout4_clicked (GtkButton *obj, gpointer user_data)
{
authentification=create_authentification();
gtk_widget_destroy(Medecin);
gtk_widget_show(authentification);v=-1;v1=-1;
}

void on_logout5_clicked (GtkButton *obj, gpointer user_data)
{
authentification=create_authentification();
gtk_widget_destroy(Kin__);
gtk_widget_show(authentification);v=-1;v1=-1;
}


void on_logout6_clicked (GtkButton *obj, gpointer user_data)
{
authentification=create_authentification();
gtk_widget_destroy(Dieteticien);
gtk_widget_show(authentification);v=-1;v1=-1;
}


void on_Admin_set_focus(GtkWindow *window, GtkWidget *widget,gpointer user_data)
{

GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;


output3=lookup_widget(window,"label36");
output4=lookup_widget(window,"label37");
output5=lookup_widget(window,"label200");
output6=lookup_widget(window,"label201");
output7=lookup_widget(window,"label202");


f1=fopen("admin.txt","r");
while(fscanf(f1,"%s %s %s %s %s\n",a.nom,a.prenom,a.num,a.login,a.password)!=EOF)
{ if(strcmp(u.login,a.login)==0 && strcmp(u.password,a.password)==0)
{
gtk_label_set_text(GTK_LABEL(output3),a.nom);
gtk_label_set_text(GTK_LABEL(output4),a.prenom);
gtk_label_set_text(GTK_LABEL(output5),a.num);
gtk_label_set_text(GTK_LABEL(output6),a.login);
gtk_label_set_text(GTK_LABEL(output7),a.password);
}
}
fclose(f1);

if(v1==-1)
{
GtkWidget *treeview5;
GtkWidget *treeview6;
GtkWidget *treeview7;
GtkWidget *treeview8;
GtkWidget *treeview9;

treeview5=lookup_widget(Admin,"treeview5");
treeview6=lookup_widget(Admin,"treeview6");
treeview7=lookup_widget(Admin,"treeview7");
treeview8=lookup_widget(Admin,"treeview8");
treeview9=lookup_widget(Admin,"treeview9");

afficher_adh(treeview5);
afficher_coach(treeview6);
afficher_diet(treeview7);
afficher_kine(treeview8);
afficher_med(treeview9);
v1=0;
}
}


void on_Adh__rent_set_focus(GtkWindow *window,GtkWidget *widget,gpointer user_data)
{


GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output10;
GtkWidget *output11;
GtkWidget *output12;
GtkWidget *output13;
GtkWidget *output14;
GtkWidget *output15;
GtkWidget *output16;

GtkWidget *output42;
GtkWidget *output43;
GtkWidget *output44;
GtkWidget *output45;
GtkWidget *output46;
GtkWidget *output47;
GtkWidget *output48;

output8=lookup_widget(window,"label71");
output9=lookup_widget(window,"label72");             
output10=lookup_widget(window,"label204");
output11=lookup_widget(window,"label77");
output12=lookup_widget(window,"label73");
output13=lookup_widget(window,"label74");
output14=lookup_widget(window,"label78");
output15=lookup_widget(window,"label79");
output16=lookup_widget(window,"label80");

output42=lookup_widget(window,"label1390");
output43=lookup_widget(window,"label1391");             
output44=lookup_widget(window,"label1392");
output45=lookup_widget(window,"label90");
output46=lookup_widget(window,"label89");
output47=lookup_widget(window,"label88");
output48=lookup_widget(window,"label1393");

f2=fopen("adherent.txt","r");
while(fscanf(f2,"%s %s %s %s %s %s %s %s %s %d\n",ad.nom,ad.prenom,ad.num,ad.date_ne,ad.sexe,ad.type_dabo,ad.payemant,ad.login,ad.password,&ad.role)!=EOF)
{ if(strcmp(u.login,ad.login)==0 && strcmp(u.password,ad.password)==0)
	{
gtk_label_set_text(GTK_LABEL(output8),ad.nom);
gtk_label_set_text(GTK_LABEL(output9),ad.prenom);
gtk_label_set_text(GTK_LABEL(output10),ad.num);
gtk_label_set_text(GTK_LABEL(output11),ad.date_ne);
gtk_label_set_text(GTK_LABEL(output12),ad.sexe);
gtk_label_set_text(GTK_LABEL(output13),ad.type_dabo);
gtk_label_set_text(GTK_LABEL(output14),ad.payemant);
gtk_label_set_text(GTK_LABEL(output15),ad.login);
gtk_label_set_text(GTK_LABEL(output16),ad.password);


	}
}
fclose(f2);
strcpy(ad.nom,gtk_label_get_text(GTK_LABEL(output8)));
strcpy(ad.prenom,gtk_label_get_text(GTK_LABEL(output9)));
f7=fopen("fiche_med.txt","r");
while(fscanf(f7,"%s %s %d/%d/%d %s %s %s %s %s %s %s %s\n",fi.a.nom,fi.a.prenom,&fi.a.dtn.jour,&fi.a.dtn.mois,&fi.a.dtn.annees,fi.a.sexe,fi.taill,fi.poids,fi.imc,fi.historique,fi.probleme,fi.medica,fi.autre)!=EOF)
{    if(strcmp(fi.a.nom,ad.nom)==0 && strcmp(fi.a.prenom,ad.prenom)==0)
	{
gtk_label_set_text(GTK_LABEL(output42),fi.historique);
gtk_label_set_text(GTK_LABEL(output43),fi.probleme);
gtk_label_set_text(GTK_LABEL(output44),fi.medica);
gtk_label_set_text(GTK_LABEL(output45),fi.taill);
gtk_label_set_text(GTK_LABEL(output46),fi.poids);
gtk_label_set_text(GTK_LABEL(output47),fi.imc);
gtk_label_set_text(GTK_LABEL(output48),fi.autre);


	}
}
fclose(f7);

if(v1==-1)
{
GtkWidget *treeview12;
treeview12=lookup_widget(Adh__rent,"treeview12");
afficher_staff(treeview12);
v1=0;
}

}


void on_Coach_set_focus(GtkWindow *window,GtkWidget *widget,gpointer user_data)
{
GtkWidget *output17;
GtkWidget *output18;
GtkWidget *output19;
GtkWidget *output20;
GtkWidget *output21;
GtkWidget *output22;
GtkWidget *output23;

output17=lookup_widget(window,"label44");
output18=lookup_widget(window,"label48");             
output19=lookup_widget(window,"label210");
output20=lookup_widget(window,"label105");
output21=lookup_widget(window,"label101");
output22=lookup_widget(window,"label206");
output23=lookup_widget(window,"label208");

f3=fopen("coach.txt","r");
while(fscanf(f3,"%s %s %s %s %s %s %s %d\n",c.nom,c.prenom,c.date_ne,c.sexe,c.specialite,c.login,c.password,&c.role)!=EOF)
{ if(strcmp(u.login,c.login)==0 && strcmp(u.password,c.password)==0)
	{
gtk_label_set_text(GTK_LABEL(output17),c.nom);
gtk_label_set_text(GTK_LABEL(output18),c.prenom);
gtk_label_set_text(GTK_LABEL(output19),c.date_ne);
gtk_label_set_text(GTK_LABEL(output20),c.sexe);
gtk_label_set_text(GTK_LABEL(output21),c.specialite);
gtk_label_set_text(GTK_LABEL(output22),c.login);
gtk_label_set_text(GTK_LABEL(output23),c.password);
	}
}
fclose(f3);

if(v1==-1)
{
GtkWidget *treeview3;
treeview3=lookup_widget(Coach,"treeview3");
afficher_adh(treeview3);
v1=0;
}

}


void on_Medecin_set_focus(GtkWindow *window,GtkWidget *widget,gpointer user_data)
{

GtkWidget *output24;
GtkWidget *output25;
GtkWidget *output26;
GtkWidget *output27;
GtkWidget *output28;
GtkWidget *output29;


output24=lookup_widget(window,"label18");
output25=lookup_widget(window,"label19");             
output26=lookup_widget(window,"label212");
output27=lookup_widget(window,"label106");
output28=lookup_widget(window,"label213");
output29=lookup_widget(window,"label214");


f4=fopen("medecin.txt","r");
while(fscanf(f4,"%s %s %s %s %s %s %d\n",m.nom,m.prenom,m.date_ne,m.sexe,m.login,m.password,&m.role)!=EOF)
{ if(strcmp(u.login,m.login)==0 && strcmp(u.password,m.password)==0)
	{
gtk_label_set_text(GTK_LABEL(output24),m.nom);
gtk_label_set_text(GTK_LABEL(output25),m.prenom);
gtk_label_set_text(GTK_LABEL(output26),m.date_ne);
gtk_label_set_text(GTK_LABEL(output27),m.sexe);
gtk_label_set_text(GTK_LABEL(output28),m.login);
gtk_label_set_text(GTK_LABEL(output29),m.password);
	}
}
fclose(f4);

if(v1==-1)
{
GtkWidget *treeview1;
treeview1=lookup_widget(Medecin,"treeview1");
afficher_fi_med(treeview1);
v1=0;
}

}


void on_Kin___set_focus(GtkWindow *window,GtkWidget *widget,gpointer user_data)
{
GtkWidget *output30;
GtkWidget *output31;
GtkWidget *output32;
GtkWidget *output33;
GtkWidget *output34;
GtkWidget *output35;


output30=lookup_widget(window,"label95");
output31=lookup_widget(window,"label97");             
output32=lookup_widget(window,"label99");
output33=lookup_widget(window,"label220");
output34=lookup_widget(window,"label222");
output35=lookup_widget(window,"label224");


f5=fopen("kine.txt","r");
while(fscanf(f5,"%s %s %s %s %s %s %d\n",k.nom,k.prenom,k.date_ne,k.sexe,k.login,k.password,&k.role)!=EOF)
{ if(strcmp(u.login,k.login)==0 && strcmp(u.password,k.password)==0)
	{
gtk_label_set_text(GTK_LABEL(output30),k.nom);
gtk_label_set_text(GTK_LABEL(output31),k.prenom);
gtk_label_set_text(GTK_LABEL(output32),k.date_ne);
gtk_label_set_text(GTK_LABEL(output33),k.sexe);
gtk_label_set_text(GTK_LABEL(output34),k.login);
gtk_label_set_text(GTK_LABEL(output35),k.password);
	}
}
fclose(f5);
}


void on_Dieteticien_set_focus(GtkWindow *window,GtkWidget *widget,gpointer user_data) 
{
GtkWidget *output36;
GtkWidget *output37;
GtkWidget *output38;
GtkWidget *output39;
GtkWidget *output40;
GtkWidget *output41;


output36=lookup_widget(window,"label102");
output37=lookup_widget(window,"label103");             
output38=lookup_widget(window,"label216");
output39=lookup_widget(window,"label104");
output40=lookup_widget(window,"label217");
output41=lookup_widget(window,"label218");


f6=fopen("dieteticien.txt","r");
while(fscanf(f6,"%s %s %s %s %s %s %d\n",d.nom,d.prenom,&d.date_ne,d.sexe,d.login,d.password,&d.role)!=EOF)
{ if(strcmp(u.login,d.login)==0 && strcmp(u.password,d.password)==0)
	{
gtk_label_set_text(GTK_LABEL(output36),d.nom);
gtk_label_set_text(GTK_LABEL(output37),d.prenom);
gtk_label_set_text(GTK_LABEL(output38),d.date_ne);
gtk_label_set_text(GTK_LABEL(output39),d.sexe);
gtk_label_set_text(GTK_LABEL(output40),d.login);
gtk_label_set_text(GTK_LABEL(output41),d.password);
	}
}
fclose(f6);


if(v1==-1)
{
GtkWidget *treeview4;
treeview4=lookup_widget(Dieteticien,"treeview4");
afficher_fi_med(treeview4);
v1=0;
}

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////////////
void on_button48_clicked(GtkButton *obj, gpointer user_data) //modifier login mot de passe medicin
{
GtkWidget *input60;
GtkWidget *input61;

char nlogin[50]="";
char npassword[50]="";

input60=lookup_widget(obj,"entry49"); //id
input61=lookup_widget(obj,"entry50"); // passe 

strcpy(nlogin,gtk_entry_get_text(GTK_ENTRY(input60)));
strcpy(npassword,gtk_entry_get_text(GTK_ENTRY(input61)));
if(strlen(nlogin)>0 && strlen(npassword)>0){
modifier_med(nlogin,npassword,u.login,u.password);
strcpy(u.login,nlogin); strcpy(u.password,npassword);

gtk_widget_destroy(Medecin);
Medecin=create_Medecin();
gtk_widget_show(Medecin);
v1=-1;
}}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
void on_button49_clicked (GtkButton *obj, gpointer user_data)  //modier login et mot de passe diet
{

GtkWidget *input62;
GtkWidget *input63;

char nlogin[50]="";
char npassword[50]="";

input62=lookup_widget(obj,"entry51"); //id
input63=lookup_widget(obj,"entry52"); // passe 

strcpy(nlogin,gtk_entry_get_text(GTK_ENTRY(input62)));
strcpy(npassword,gtk_entry_get_text(GTK_ENTRY(input63)));
if(strlen(nlogin)>0 && strlen(npassword)>0){
modifier_diet(nlogin,npassword,u.login,u.password);
strcpy(u.login,nlogin); strcpy(u.password,npassword);

gtk_widget_destroy(Dieteticien);
Dieteticien=create_Dieteticien();
gtk_widget_show(Dieteticien);
v1=-1;
}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void on_button50_clicked(GtkButton *obj, gpointer user_data) //modier login et mot de passe kine
{

GtkWidget *input64;
GtkWidget *input65;

char nlogin[50]="";
char npassword[50]="";

input64=lookup_widget(obj,"entry54"); //id
input65=lookup_widget(obj,"entry55"); // passe 

strcpy(nlogin,gtk_entry_get_text(GTK_ENTRY(input64)));
strcpy(npassword,gtk_entry_get_text(GTK_ENTRY(input65)));
if(strlen(nlogin)>0 && strlen(npassword)>0){
modifier_kine(nlogin,npassword,u.login,u.password);
strcpy(u.login,nlogin); strcpy(u.password,npassword);

gtk_widget_destroy(Kin__);
Kin__=create_Kin__();
gtk_widget_show(Kin__);
v1=-1;
}}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void on_button9_clicked(GtkButton *obj, gpointer user_data) //modier login et mot de passe Admin
{

GtkWidget *input66;
GtkWidget *input67;
char nlogin[50]="";
char npassword[50]="";
input66=lookup_widget(obj,"entry3"); //id
input67=lookup_widget(obj,"entry4"); // passe 
strcpy(nlogin,gtk_entry_get_text(GTK_ENTRY(input66)));
strcpy(npassword,gtk_entry_get_text(GTK_ENTRY(input67)));

//printf("nlogin = %d npassword= %d  \n ",strlen(nlogin),strlen(npassword));

if(strlen(nlogin)>0 && strlen(npassword)>0){
modifier_admin(nlogin,npassword,u.login,u.password);
strcpy(u.login,nlogin); strcpy(u.password,npassword);

gtk_widget_destroy(Admin);
Admin=create_Admin();
gtk_widget_show(Admin);
v1=-1;
}

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void on_button46_clicked(GtkButton *obj, gpointer user_data) //modier login et mot de passe Adherant 
{
GtkWidget *input68;
GtkWidget *input69;
char nlogin[50]="";
char npassword[50]="";
input68=lookup_widget(obj,"entry5"); //id
input69=lookup_widget(obj,"entry6"); // passe 
strcpy(nlogin,gtk_entry_get_text(GTK_ENTRY(input68)));
strcpy(npassword,gtk_entry_get_text(GTK_ENTRY(input69)));
if(strlen(nlogin)>0 && strlen(npassword)>0){
modifier_adh(nlogin,npassword,u.login,u.password);
strcpy(u.login,nlogin); strcpy(u.password,npassword);

gtk_widget_destroy(Adh__rent);
Adh__rent=create_Adh__rent();
gtk_widget_show(Adh__rent);
v1=-1;
}}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void on_button47_clicked(GtkButton *obj, gpointer user_data) //modier login et mot de passe coach 
{

GtkWidget *input70;
GtkWidget *input71;
char nlogin[50]="";
char npassword[50]="";
input70=lookup_widget(obj,"entry47"); //id
input71=lookup_widget(obj,"entry48"); // passe 
strcpy(nlogin,gtk_entry_get_text(GTK_ENTRY(input70)));
strcpy(npassword,gtk_entry_get_text(GTK_ENTRY(input71)));
if(strlen(nlogin)>0 && strlen(npassword)>0){
modifier_coach(nlogin,npassword,u.login,u.password);
strcpy(u.login,nlogin); strcpy(u.password,npassword);

gtk_widget_destroy(Coach);
Coach=create_Coach();
gtk_widget_show(Coach);
v1=-1;
}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	NOM5,
	PRENOM5,
	SEXE5,                //recupurer données depuis treeview admin for medicin 
	DATE5,
	COLUMNS5

};

gchar *name5=NULL;
gchar *prenom5=NULL;
void on_treeview9_row_activated(GtkTreeView *treeview,GtkTreePath *path,GtkTreeViewColumn *column,gpointer user_data)
{

	GtkTreeIter   iter;
  	GtkTreeModel *model;

  model = gtk_tree_view_get_model(treeview);

  if (gtk_tree_model_get_iter(model, &iter, path))
  {

    gtk_tree_model_get(GTK_LIST_STORE(model), &iter,NOM5 ,&name5,PRENOM5,&prenom5, -1);

}}
//-------------------------------------------------------------------------------------------------------------//
void on_button45_clicked (GtkButton *obj, gpointer user_data) // supprimer medicin 
{
if(name5!=NULL && prenom5!=NULL)
{
sup_med(name5,prenom5);
gtk_widget_destroy(Admin);
Admin=create_Admin();
gtk_widget_show(Admin);
v1=-1;
}
name5=NULL;prenom5=NULL;
}
//--------------------------------------------------------------------------------------------------------------//

void on_button44_clicked (GtkButton *obj, gpointer user_data)// Modifier medicin 
{

if(name5!=NULL && prenom5!=NULL ){ if(wf==0 && w==0){

Ajout_medcin=lookup_widget(obj,"Ajout_medcin");
Ajout_medcin=create_Ajout_medcin();
gtk_widget_show(Ajout_medcin);
wf=1;

}}

}

//--------------------------------------------------------------------------------------------------//
void on_button43_clicked(GtkWidget *obj, gpointer user_data) //ajout  med
{
name5=NULL;prenom5=NULL;
if(w==0 && wf==0)
{
Ajout_medcin=lookup_widget(obj,"Ajout_medcin");
Ajout_medcin=create_Ajout_medcin();
gtk_widget_show(Ajout_medcin);

}
w=1;

}

//----------------------------------------------------------------------------------------------------//
void on_button16_clicked(GtkWidget *obj, gpointer user_data) //sauvegarder
{
m.role=4;

GtkWidget *input11;	// ID
GtkWidget *input12;     //nom
GtkWidget *input13; 	//prenom
GtkWidget *input14; 	//jour
GtkWidget *input15;	//mois 
GtkWidget *input16; 	//années
GtkWidget *input17;  	// sexe 
GtkWidget *input18;	// passe 


input11=lookup_widget(obj,"entry229");
input12=lookup_widget(obj,"entry230");
input13=lookup_widget(obj,"entry231");
input17=lookup_widget(obj,"combobox6");
input18=lookup_widget(obj,"entry232");
input14=lookup_widget(obj,"spinbutton19");
input15=lookup_widget(obj,"spinbutton20");
input16=lookup_widget(obj,"spinbutton21");


m.dtn.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input14));
m.dtn.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input15));
m.dtn.annees=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input16));

strcpy(m.login,gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(m.nom,gtk_entry_get_text(GTK_ENTRY(input12)));
strcpy(m.prenom,gtk_entry_get_text(GTK_ENTRY(input13)));
strcpy(m.password,gtk_entry_get_text(GTK_ENTRY(input18)));
strcpy(m.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input17)));
if(w==1){
ajouter_med(m);}
if(wf==1)
{

modifier2_med(m,name5,prenom5);

}
gtk_widget_destroy(Ajout_medcin);
Ajout_medcin=create_Ajout_medcin();
gtk_widget_show(Ajout_medcin);
v1=-1;
}
//----------------------------------------------------------------------------------------------------------------------//
void on_button17_clicked(GtkWidget *obj, gpointer user_data) //quitter la fenetre
{
gtk_widget_destroy(Ajout_medcin);
w=0;wf=0;name5=NULL;prenom5=NULL;
gtk_widget_destroy(Admin);
Admin=create_Admin();
gtk_widget_show(Admin);
v1=-1;
}
//-----------------------------------------------------------------------------------------------------------------------//
void on_Ajout_medcin_set_focus (GtkWindow *window, GtkWidget *widget,gpointer user_data)
{
GtkWidget *input12;     //nom
GtkWidget *input13;	//prenom
input12=lookup_widget(window,"entry230");
input13=lookup_widget(window,"entry231");
if(wf==0)
{
gtk_entry_set_text(GTK_ENTRY(input12),name5);
gtk_entry_set_text(GTK_ENTRY(input13),prenom5);}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	NOM4,
	PRENOM4,
	SEXE4,                //recupurer données depuis treeview admin for medicin 
	DATE4,
	COLUMNS4

};

gchar *name4=NULL;
gchar *prenom4=NULL;
void on_treeview8_row_activated(GtkTreeView *treeview, GtkTreePath *path,GtkTreeViewColumn *column,gpointer user_data)//treeview espace admin-->kine
{

	GtkTreeIter   iter;
  	GtkTreeModel *model;

  model = gtk_tree_view_get_model(treeview);

  if (gtk_tree_model_get_iter(model, &iter, path))
  {

    gtk_tree_model_get(GTK_LIST_STORE(model), &iter,NOM4 ,&name4,PRENOM4,&prenom4, -1);
}

}
void on_button41_clicked(GtkButton  *obj, gpointer user_data) // modifier coordoners kine 
{

if(name4!=NULL && prenom4!=NULL ){ if(wf==0 && w==0){

Ajout_kin__=lookup_widget(obj,"Ajout_kin__");
Ajout_kin__=create_Ajout_kin__();
gtk_widget_show(Ajout_kin__);
wf=1;

}}



}
void on_button42_clicked (GtkButton  *obj,gpointer user_data) // supprumer kine 
{

if(name4!=NULL && prenom4!=NULL)
{
sup_kine(name4,prenom4);
gtk_widget_destroy(Admin);
Admin=create_Admin();
gtk_widget_show(Admin);
v1=-1;
}
name4=NULL;prenom4=NULL;
}
void on_button40_clicked (GtkWidget *obj, gpointer user_data)  //ajout kine   Ajout_kin__ 
{
name5=NULL;prenom5=NULL;
if(w==0 && wf==0)
{
Ajout_kin__=lookup_widget(obj,"Ajout_kin__");
Ajout_kin__=create_Ajout_kin__();
gtk_widget_show(Ajout_kin__);}
w=1;
}

void on_button19_clicked (GtkWidget *obj, gpointer user_data) //sauvegarder
{

k.role=5;
GtkWidget *input19;	// ID
GtkWidget *input20;     //nom
GtkWidget *input21; 	//prenom
GtkWidget *input22; 	//jour
GtkWidget *input23;	//mois 
GtkWidget *input24; 	//années
GtkWidget *input25;  	// sexe 
GtkWidget *input26;	// passe 


input20=lookup_widget(obj,"entry225");
input21=lookup_widget(obj,"entry226");
input19=lookup_widget(obj,"entry227");
input25=lookup_widget(obj,"combobox3");
input26=lookup_widget(obj,"entry228");
input22=lookup_widget(obj,"spinbutton10");
input23=lookup_widget(obj,"spinbutton11");
input24=lookup_widget(obj,"spinbutton12");

k.dtn.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input22));
k.dtn.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input23));
k.dtn.annees=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input24));

strcpy(k.login,gtk_entry_get_text(GTK_ENTRY(input19)));
strcpy(k.nom,gtk_entry_get_text(GTK_ENTRY(input20)));
strcpy(k.prenom,gtk_entry_get_text(GTK_ENTRY(input21)));
strcpy(k.password,gtk_entry_get_text(GTK_ENTRY(input26)));
strcpy(k.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input25)));
if(w==1)
{
ajouter_kine( k);
}
if(wf==1)
{
modifier2_kine(k,name4,prenom4);

}

gtk_widget_destroy(Ajout_kin__);
Ajout_kin__=create_Ajout_kin__();
gtk_widget_show(Ajout_kin__);
}


void on_button18_clicked (GtkWidget *obj, gpointer user_data) //quitter 
{
gtk_widget_destroy(Ajout_kin__);
w=0;wf=0;name5=NULL;prenom5=NULL;
gtk_widget_destroy(Admin);
Admin=create_Admin();
gtk_widget_show(Admin);
v1=-1;

}
void on_Ajout_kin___set_focus(GtkWindow  *window,GtkWidget *widget,gpointer  user_data)//set focus modif kine
{
GtkWidget *input12;     //nom
GtkWidget *input13;	//prenom
input12=lookup_widget(window,"entry225");
input13=lookup_widget(window,"entry226");
if(wf==0)
{
gtk_entry_set_text(GTK_ENTRY(input12),name4);
gtk_entry_set_text(GTK_ENTRY(input13),prenom4);}

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	NOM3,
	PRENOM3,
	SEXE3,                //recupurer données depuis treeview admin for diet 
	DATE3,
	COLUMNS3

};
gchar *name3=NULL;
gchar *prenom3=NULL;

void on_treeview7_row_activated(GtkTreeView *treeview, GtkTreePath *path,GtkTreeViewColumn *column,gpointer user_data)//treeview espace admin-->diet
{

	GtkTreeIter   iter;
  	GtkTreeModel *model;

  model = gtk_tree_view_get_model(treeview);

  if (gtk_tree_model_get_iter(model, &iter, path))
  {

    gtk_tree_model_get(GTK_LIST_STORE(model), &iter,NOM3 ,&name3,PRENOM3,&prenom3, -1);
	
}

}

void on_button39_clicked(GtkButton  *obj, gpointer user_data)// supprimer  diet 
{

if(name3!=NULL && prenom3!=NULL)
{
sup_diet(name3,prenom3);
gtk_widget_destroy(Admin);
Admin=create_Admin();
gtk_widget_show(Admin);
v1=-1;
}
name3=NULL;prenom3=NULL;

}
//--------------------------------------------------------------------------------------------//
void on_button38_clicked(GtkButton  *obj, gpointer user_data) // modifier coordoners diet 
{

if(name3!=NULL && prenom3!=NULL ){ if(wf==0 && w==0){

Ajout_dieteticien=lookup_widget(obj,"Ajout_dieteticien");
Ajout_dieteticien=create_Ajout_dieteticien();
gtk_widget_show(Ajout_dieteticien);
wf=1;

}}

}


void on_button37_clicked (GtkWidget *obj, gpointer user_data) //ajout diet
{
name3=NULL;prenom3=NULL;
if(w==0 && wf==0)
{
Ajout_dieteticien=lookup_widget(obj,"Ajout_dieteticien");
Ajout_dieteticien=create_Ajout_dieteticien();
gtk_widget_show(Ajout_dieteticien);}
w=1;

}

void on_button20_clicked (GtkButton *obj, gpointer user_data) // sauvegarder
{
dieteticien d1;
d1.role=6;
GtkWidget *input3;	// ID
GtkWidget *input4;     	//nom
GtkWidget *input5; 	//prenom
GtkWidget *input6; 	//jour
GtkWidget *input7;	//mois 
GtkWidget *input8; 	//années
GtkWidget *input9;  	// sexe 
GtkWidget *input10;	// passe 


input3=lookup_widget(obj,"entry56");
input4=lookup_widget(obj,"entry57");
input5=lookup_widget(obj,"entry58");
input9=lookup_widget(obj,"combobox2");
input10=lookup_widget(obj,"entry59");
input6=lookup_widget(obj,"spinbutton7");
input7=lookup_widget(obj,"spinbutton8");
input8=lookup_widget(obj,"spinbutton9");

d1.datn.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
d1.datn.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
d1.datn.annees=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));

strcpy(d1.login,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(d1.nom,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(d1.prenom,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(d1.password,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(d1.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input9)));

if(w==1)
{
ajouter_det( d1);
}
if(wf==1)
{
modifier2_diet(d1,name3,prenom3);
}
gtk_widget_destroy(Ajout_dieteticien);
Ajout_dieteticien=create_Ajout_dieteticien();
gtk_widget_show(Ajout_dieteticien);
}

void on_button21_clicked (GtkButton *obj, gpointer user_data) //quitter la fenetre
{

gtk_widget_destroy(Ajout_dieteticien);
w=0;wf=0;name3=NULL;prenom3=NULL;
gtk_widget_destroy(Admin);
Admin=create_Admin();
gtk_widget_show(Admin);
v1=-1;
}



void on_Ajout_dieteticien_set_focus(GtkWindow  *window, GtkWidget *widget,gpointer user_data)//set focus 
{

GtkWidget *input12;     //nom
GtkWidget *input13;	//prenom
input12=lookup_widget(window,"entry57");
input13=lookup_widget(window,"entry58");
if(wf==0)
{
gtk_entry_set_text(GTK_ENTRY(input12),name3);
gtk_entry_set_text(GTK_ENTRY(input13),prenom3);}

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	NOM2,
	PRENOM2,    //affichage treeview coach
	SEXE2,
	DATE2,
	SPECIALITE2,
	COLUMNS2

};
gchar *name2=NULL;
gchar *prenom2=NULL;

void on_treeview6_row_activated(GtkTreeView *treeview,GtkTreePath *path,GtkTreeViewColumn *column,gpointer user_data)//treeview espace admin-->coach
{
GtkTreeIter   iter;
  	GtkTreeModel *model;

  model = gtk_tree_view_get_model(treeview);

  if (gtk_tree_model_get_iter(model, &iter, path))
  {

    gtk_tree_model_get(GTK_LIST_STORE(model), &iter,NOM2 ,&name2,PRENOM2,&prenom2, -1);

}

}

void on_button35_clicked(GtkWidget *obj, gpointer user_data) //modifier coach 
{
if(name2!=NULL && prenom2!=NULL ){ if(wf==0 && w==0){

Ajout_coach=lookup_widget(obj,"Ajout_coach");
Ajout_coach=create_Ajout_coach();
gtk_widget_show(Ajout_coach);
wf=1;

}}

}
void on_button36_clicked(GtkWidget *obj, gpointer user_data)//supprimer  coach 
{
if(name2!=NULL && prenom2!=NULL)
{
sup_coach(name2,prenom2);
gtk_widget_destroy(Admin);
Admin=create_Admin();
gtk_widget_show(Admin);
v1=-1;

}
name2=NULL ; prenom2=NULL;
}


void on_button34_clicked (GtkWidget *obj, gpointer user_data) //ajout coach  Ajout_coach
{
if(w==0)
{
Ajout_coach=lookup_widget(obj,"Ajout_coach");
Ajout_coach=create_Ajout_coach();
gtk_widget_show(Ajout_coach);}
w=1;
}

void on_button13_clicked (GtkWidget *obj, gpointer user_data)  //sauvegarder
{

c.role=3;
GtkWidget *input27;	// ID
GtkWidget *input28;     //nom
GtkWidget *input29; 	//prenom
GtkWidget *input30; 	//jour
GtkWidget *input31;	//mois 
GtkWidget *input32; 	//années
GtkWidget *input33;  	// sexe 
GtkWidget *input34;	// passe 
GtkWidget *input35;	//specialite


input27=lookup_widget(obj,"entry221");
input28=lookup_widget(obj,"entry222");
input29=lookup_widget(obj,"entry223");
input33=lookup_widget(obj,"combobox5");
input35=lookup_widget(obj,"comboboxentry3");
input34=lookup_widget(obj,"entry224");
input30=lookup_widget(obj,"spinbutton16");
input31=lookup_widget(obj,"spinbutton17");
input32=lookup_widget(obj,"spinbutton18");

c.dtn.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input30));
c.dtn.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input31));
c.dtn.annees=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input32));

strcpy(c.login,gtk_entry_get_text(GTK_ENTRY(input27)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input28)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input29)));
strcpy(c.password,gtk_entry_get_text(GTK_ENTRY(input34)));
strcpy(c.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input33)));
strcpy(c.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input35)));
if(w==1)
{
ajouter_coach( c);
}
if(wf==1)
{
modifier2_coach(c,name2,prenom2);

}

gtk_widget_destroy(Ajout_coach);
Ajout_coach=create_Ajout_coach();
gtk_widget_show(Ajout_coach);
}


void on_button14_clicked (GtkWidget *obj, gpointer user_data)  //quitter
{
gtk_widget_destroy(Ajout_coach);
w=0;wf=0;name2=NULL;prenom2=NULL;
gtk_widget_destroy(Admin);
Admin=create_Admin();
gtk_widget_show(Admin);
v1=-1;
}

void on_Ajout_coach_set_focus(GtkWindow  *window, GtkWidget *widget,gpointer user_data)//set focus
{

GtkWidget *input12;     //nom
GtkWidget *input13;	//prenom
input12=lookup_widget(window,"entry222");
input13=lookup_widget(window,"entry223");
if(wf==0)
{
gtk_entry_set_text(GTK_ENTRY(input12),name2);
gtk_entry_set_text(GTK_ENTRY(input13),prenom2);}

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{

	NOM6,
	PRENOM6,
	SEXE6,						//affichage treeview fiche medicale
	DATE6,
	COLUMNS6

};
gchar *name6=NULL;
gchar *prenom6=NULL;

void on_treeview1_row_activated(GtkTreeView *treeview,GtkTreePath*path,GtkTreeViewColumn *column, gpointer user_data)//treeview espace medicin-->fichemidical
{

GtkTreeIter   iter;
  	GtkTreeModel *model;

  model = gtk_tree_view_get_model(treeview);

  if (gtk_tree_model_get_iter(model, &iter, path))
  {

    gtk_tree_model_get(GTK_LIST_STORE(model), &iter,NOM6 ,&name6,PRENOM6,&prenom6, -1);

}
}

void on_treeview4_row_activated(GtkTreeView *treeview,GtkTreePath*path,GtkTreeViewColumn *column, gpointer user_data)//treeview espace medicin-
{
	GtkTreeIter   iter;
  	GtkTreeModel *model;

  model = gtk_tree_view_get_model(treeview);

  if (gtk_tree_model_get_iter(model, &iter, path))
  {

    gtk_tree_model_get(GTK_LIST_STORE(model), &iter,NOM6 ,&name6,PRENOM6,&prenom6, -1);

}
}


void on_button52_clicked(GtkWidget *obj, gpointer user_data) //modifier fich medical 
{
if(name6!=NULL && prenom6!=NULL ){ if(wf==0 && w==0){

fiche_med=lookup_widget(obj,"fiche_med");
fiche_med=create_fiche_med();
gtk_widget_show(fiche_med);
wf=1;

}}
}
void on_button53_clicked(GtkWidget *obj, gpointer user_data) //supprimer fiche fich medical 
{

if(name6!=NULL && prenom6!=NULL)
{
sup_fi_med(name6,prenom6);
gtk_widget_destroy(Medecin);
Medecin=create_Medecin();
gtk_widget_show(Medecin);
v1=-1;

}
name6=NULL ; prenom6=NULL;
}

void on_button51_clicked (GtkButton *obj,gpointer  user_data) //ajout fich medicale
{
if(w==0){
fiche_med=lookup_widget(obj,"fiche_med");
fiche_med=create_fiche_med();
gtk_widget_show(fiche_med);}
w=1;
}


void on_button23_clicked (GtkButton *obj,gpointer  user_data) //sauvegarder fiche medical 
{

GtkWidget *input47;	// nom
GtkWidget *input48;     //prenom
GtkWidget *input49; 	//jour
GtkWidget *input50; 	//mois
GtkWidget *input51;	//annees 
GtkWidget *input52; 	//sexe
GtkWidget *input53;  	// historique 
GtkWidget *input54;	// probléme mideceau 
GtkWidget *input55;	//taill
GtkWidget *input56;	//poid
GtkWidget *input57;	//imc
GtkWidget *input58;	//medicament
GtkWidget *input59;	//autre


input47=lookup_widget(obj,"entry237");
input48=lookup_widget(obj,"entry238");
input49=lookup_widget(obj,"spinbutton22");
input50=lookup_widget(obj,"spinbutton23");
input51=lookup_widget(obj,"spinbutton24");
input52=lookup_widget(obj,"comboboxentry4");
input53=lookup_widget(obj,"entry233");
input54=lookup_widget(obj,"entry234");
input55=lookup_widget(obj,"entry239");
input56=lookup_widget(obj,"entry240");
input57=lookup_widget(obj,"entry241");
input58=lookup_widget(obj,"entry235");
input59=lookup_widget(obj,"entry236");

fi.a.dtn.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input49));
fi.a.dtn.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input50));
fi.a.dtn.annees=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input51));

strcpy(fi.a.nom,gtk_entry_get_text(GTK_ENTRY(input47)));
strcpy(fi.a.prenom,gtk_entry_get_text(GTK_ENTRY(input48)));
strcpy(fi.medica,gtk_entry_get_text(GTK_ENTRY(input58)));
strcpy(fi.historique,gtk_entry_get_text(GTK_ENTRY(input53)));
strcpy(fi.probleme,gtk_entry_get_text(GTK_ENTRY(input54)));
strcpy(fi.autre,gtk_entry_get_text(GTK_ENTRY(input59)));
strcpy(fi.taill,gtk_entry_get_text(GTK_ENTRY(input55)));
strcpy(fi.poids,gtk_entry_get_text(GTK_ENTRY(input56)));
strcpy(fi.imc,gtk_entry_get_text(GTK_ENTRY(input57)));
strcpy(fi.a.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input52)));
if(w==1)
{
ajouter_fiche_med(fi);
}
if(wf==1)
{
modifier2_fich_med(fi,name6,prenom6); 
}
gtk_widget_destroy(fiche_med);
fiche_med=create_fiche_med();
gtk_widget_show(fiche_med);
}

void on_button22_clicked (GtkButton *obj,gpointer  user_data) // quitter fiche medical 
{
gtk_widget_destroy(fiche_med);
w=0;wf=0;name6=NULL;prenom6=NULL;
gtk_widget_destroy(Medecin);
Medecin=create_Medecin();
gtk_widget_show(Medecin);
v1=-1;
}
void on_fiche_med_set_focus(GtkWindow  *window,GtkWidget  *widget,gpointer user_data)//set focus fiche medical 
{


GtkWidget *input47;	// nom
GtkWidget *input48;     //prenom
input47=lookup_widget(window,"entry237");
input48=lookup_widget(window,"entry238");
if(wf==0)
{
gtk_entry_set_text(GTK_ENTRY(input47),name6);
gtk_entry_set_text(GTK_ENTRY(input48),prenom6);
}

}

void on_button62_clicked (GtkButton *obj,gpointer  user_data) // afficher fiche
{
if(name6!=NULL && prenom6!=NULL)
{
window1=lookup_widget(obj,"window1");
window1=create_window1();
gtk_widget_show(window1);
}

} 
void on_button61_clicked (GtkButton *obj,gpointer  user_data) // quitter  window fiche 
{

gtk_widget_destroy(window1);

}

void on_button63_clicked (GtkButton *obj,gpointer  user_data) // afficher fiche depuis kine
{
if(name6!=NULL && prenom6!=NULL)
{
window1=lookup_widget(obj,"window1");
window1=create_window1();
gtk_widget_show(window1);
}
}

void on_window1_set_focus (GtkWindow *window,GtkWidget *widget, gpointer  user_data)
{

fihe_med m;
GtkWidget *input89;     //nom
GtkWidget *input90;	//prenom
GtkWidget *input91;     //date de naissance
GtkWidget *input92;	//sexe
GtkWidget *input93;     //historique
GtkWidget *input94;	//probleme
GtkWidget *input95;     //taille
GtkWidget *input96;	//poids
GtkWidget *input97;     //IMC
GtkWidget *input98;     //Medicaments
GtkWidget *input99;	//autres

input89=lookup_widget(window,"label1451");
input90=lookup_widget(window,"label1452");
input91=lookup_widget(window,"label1453");
input92=lookup_widget(window,"label1454");
input93=lookup_widget(window,"label1455");
input94=lookup_widget(window,"label1456");
input95=lookup_widget(window,"label1457");
input96=lookup_widget(window,"label1458");
input97=lookup_widget(window,"label1459");
input98=lookup_widget(window,"label1460");
input99=lookup_widget(window,"label1461");

f7=fopen("fiche_med.txt","r");

while(fscanf(f7,"%s %s %s %s %s %s %s %s %s %s %s\n",m.a.nom,m.a.prenom,m.a.date_ne,m.a.sexe,m.taill,m.poids,m.imc,m.historique,m.probleme,m.medica,m.autre)!=EOF)
{
if (strcmp(m.a.nom,name6)==0 && strcmp(m.a.prenom,prenom6)==0)
{
	gtk_label_set_text(GTK_LABEL(input89),m.a.nom);
	gtk_label_set_text(GTK_LABEL(input90),m.a.prenom);
	gtk_label_set_text(GTK_LABEL(input91),m.a.date_ne);
	gtk_label_set_text(GTK_LABEL(input92),m.a.sexe);
	gtk_label_set_text(GTK_LABEL(input93),m.historique);
	gtk_label_set_text(GTK_LABEL(input94),m.probleme);
	gtk_label_set_text(GTK_LABEL(input95),m.taill);
	gtk_label_set_text(GTK_LABEL(input96),m.poids);
	gtk_label_set_text(GTK_LABEL(input97),m.imc);
	gtk_label_set_text(GTK_LABEL(input98),m.medica);
	gtk_label_set_text(GTK_LABEL(input99),m.autre);
}

}

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

enum
{
	NOM1,
	PRENOM1,
	SEXE1,
	TYPE1,
	DATE1,
	COLUMNS1

};
gchar *name1=NULL;
gchar *prenom1=NULL;
void on_treeview5_row_activated(GtkTreeView *treeview,GtkTreePath *path,GtkTreeViewColumn *column,gpointer user_data)//treeview espace admin-->adherant
{

	GtkTreeIter   iter;
  	GtkTreeModel *model;

  model = gtk_tree_view_get_model(treeview);

  if (gtk_tree_model_get_iter(model, &iter, path))
  {

    gtk_tree_model_get(GTK_LIST_STORE(model), &iter,NOM1 ,&name1,PRENOM1,&prenom1, -1);

}
printf("name =%s prenom = %s \n",name1, prenom1);
}


void on_button32_clicked (GtkButton *obj, gpointer user_data) //modifier coordonnées adherant 
{

if(name1!=NULL && prenom1!=NULL ){ if(wf==0 && w==0){

Ajout_Adh__rent=lookup_widget(obj,"Ajout_Adh__rent");
Ajout_Adh__rent=create_Ajout_Adh__rent();
gtk_widget_show(Ajout_Adh__rent);
wf=1;

}}

}


void on_button33_clicked (GtkButton *obj, gpointer user_data)	// supprimer adhernat 
{

if(name1!=NULL && prenom1!=NULL)
{
sup_adh(name1,prenom1);
gtk_widget_destroy(Admin);
Admin=create_Admin();
gtk_widget_show(Admin);
v1=-1;

}
name1=NULL ; prenom1=NULL;
}

void on_button31_clicked (GtkWidget *obj, gpointer user_data) //ajout adh
{
name1=NULL ; prenom1=NULL;
if(w==0 && wf==0)
{
Ajout_Adh__rent=lookup_widget(obj,"Ajout_Adh__rent");
Ajout_Adh__rent=create_Ajout_Adh__rent();
gtk_widget_show(Ajout_Adh__rent);
}
w=1;

}


void on_button12_clicked (GtkWidget *obj, gpointer user_data)  //sauvegarder 
{
adherent h;
h.role=2;
GtkWidget *input36;	// ID
GtkWidget *input37;     //nom
GtkWidget *input38; 	//prenom
GtkWidget *input39; 	//jour
GtkWidget *input40;	//mois 
GtkWidget *input41; 	//années
GtkWidget *input42;  	// sexe 
GtkWidget *input43;	// passe 
GtkWidget *input44;	//type_dabo
GtkWidget *input45;	//payemant
GtkWidget *input46;	//num


input36=lookup_widget(obj,"entry60");
input37=lookup_widget(obj,"entry61");
input38=lookup_widget(obj,"entry62");
input42=lookup_widget(obj,"combobox4");
input44=lookup_widget(obj,"comboboxentry5");
input45=lookup_widget(obj,"comboboxentry6");
input43=lookup_widget(obj,"entry64");
input46=lookup_widget(obj,"entry63");
input39=lookup_widget(obj,"spinbutton13");
input40=lookup_widget(obj,"spinbutton14");
input41=lookup_widget(obj,"spinbutton15");

h.dtn.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input39));
h.dtn.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input40));
h.dtn.annees=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input41));

strcpy(h.login,gtk_entry_get_text(GTK_ENTRY(input36)));
strcpy(h.num,gtk_entry_get_text(GTK_ENTRY(input46)));
strcpy(h.nom,gtk_entry_get_text(GTK_ENTRY(input37)));
strcpy(h.prenom,gtk_entry_get_text(GTK_ENTRY(input38)));
strcpy(h.password,gtk_entry_get_text(GTK_ENTRY(input43)));
strcpy(h.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input42)));
strcpy(h.payemant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input45)));
strcpy(h.type_dabo,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input44)));
if(w==1)
{
ajouter_adh( h);}
if(wf==1)
{
modifier2_adh(h,name1,prenom1);
}
gtk_widget_destroy(Ajout_Adh__rent);
Ajout_Adh__rent=create_Ajout_Adh__rent();
gtk_widget_show(Ajout_Adh__rent);
v1=-1;

}


void on_button11_clicked (GtkWidget *obj, gpointer user_data)  //quitter
{
gtk_widget_destroy(Ajout_Adh__rent);
w=0;wf=0;name1=NULL;prenom1=NULL;
gtk_widget_destroy(Admin);
Admin=create_Admin();
gtk_widget_show(Admin);
v1=-1;
}

void on_Ajout_Adh__rent_set_focus (GtkWindow *window, GtkWidget *widget, gpointer  user_data)//set focus modif adherant 
{
GtkWidget *input37;     //nom
GtkWidget *input38;	//prenom
input37=lookup_widget(window,"entry61");
input38=lookup_widget(window,"entry62");
if(wf==0)
{
gtk_entry_set_text(GTK_ENTRY(input37),name1);
gtk_entry_set_text(GTK_ENTRY(input38),prenom1);}


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

enum
{
	NOM,
	PRENOM,
	SEXE,
	DATE,
	ROLE,
	COLUMNS

};
    gchar *name;
    gchar *prenom;
   gchar *datee;
    gchar *sexe;
    gint *role;
void on_treeview12_row_activated(GtkTreeView *treeview,GtkTreePath *path,GtkTreeViewColumn *column,gpointer user_data)
{

	GtkTreeIter   iter;
  	GtkTreeModel *model;

  model = gtk_tree_view_get_model(treeview);

  if (gtk_tree_model_get_iter(model, &iter, path))
  {


    gtk_tree_model_get(GTK_LIST_STORE(model), &iter,NOM ,&name,PRENOM,&prenom,DATE,&datee,SEXE,&sexe,ROLE,&role, -1);

    printf ("The row containing the name '%s' %s %s %d  has been double-clicked.\n", name,prenom,sexe,role);

    //g_free(name);
}

}

void on_button54_clicked (GtkButton  *obj,gpointer  user_data) //ouvrie fenetre dispo ( staff to view for adherant  )
{

  dispo = create_dispo ();
  gtk_widget_show (dispo);


}
int rdv=0;
void on_dispo_set_focus (GtkWindow *window,GtkWidget *widget,gpointer user_data) // set focus fenetre dispo 
{
char spc[30]="";
dispo1 ds;
char date[50];
if(role==3){   strcpy(spc,"coach"); }
if(role==4){   strcpy(spc,"medicin"); }
if(role==5){   strcpy(spc,"kine"); }
if(role==6){   strcpy(spc,"dieteticien"); }

GtkWidget *output49;     //nom
GtkWidget *output50;	//prenom
GtkWidget *output51;	//date
GtkWidget *output52;	//sexe
GtkWidget *output53;	//role
output49=lookup_widget(window,"label1399");
output50=lookup_widget(window,"label1400");
output51=lookup_widget(window,"label1401");
output52=lookup_widget(window,"label1402");
output53=lookup_widget(window,"label1403");

gtk_label_set_text(GTK_LABEL(output49),name);
gtk_label_set_text(GTK_LABEL(output50),prenom);
gtk_label_set_text(GTK_LABEL(output51),datee);
gtk_label_set_text(GTK_LABEL(output52),sexe);
gtk_label_set_text(GTK_LABEL(output53),spc);
if(rdv==0)
{
	GtkWidget *input88;     
  	GtkWidget *output59; 
  	output59=lookup_widget(window,"combobox7");
	f8=fopen("dispo.txt","r");
	while(fscanf(f8,"%s %s %d %s %s \n",ds.nom,ds.prenom,&ds.role,ds.date_ds,ds.horaire)!=EOF)
{   if(strcmp(ds.nom,name)==0 && strcmp(ds.prenom,prenom)==0)
{ 	strcpy(date,ds.date_ds); strcat(date, ":"); strcat(date, ds.horaire);
	gtk_combo_box_append_text (GTK_COMBO_BOX (output59), _(date) ); }

}
rdv=1;
}

}

void on_button55_clicked (GtkButton  *obj,gpointer  user_data) //quitter fenetre dsipo 
{
gtk_widget_destroy(dispo);
rdv=0;
}

void on_button56_clicked (GtkButton *obj,gpointer  user_data)  // confirmer rdv 
{
	GtkWidget *output59; 
	GtkWidget *output60; 
  	output59=lookup_widget(obj,"combobox7");
	 output60=lookup_widget(obj,"label1410");
strcpy(rd.nom,ad.nom);
strcpy(rd.prenom,ad.prenom);
strcpy(rd.nom1,name);
strcpy(rd.prenom1,prenom);
  f9=fopen("rdv.txt","a");
if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(output59))!=NULL)
{
strcpy(rd.date,gtk_combo_box_get_active_text(GTK_COMBO_BOX(output59)));
}
 if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(output59))!=NULL)
{

 fprintf(f9,"%s %s %s %s %s \n",rd.nom,rd.prenom,rd.nom1,rd.prenom1,rd.date);
gtk_label_set_text(GTK_LABEL(output60),"votre choix est confirmée ");
}
 if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(output59))==NULL)
{
 gtk_label_set_text(GTK_LABEL(output60),"veuillez choisir une date");

}

fclose(f9);

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void on_button57_clicked (GtkButton *obj,gpointer  user_data)  // ajout dispo medicin  
{
dispo1 ds;
GtkWidget *input72; //jour  spin
GtkWidget *input73; //mois  spin
GtkWidget *input74; //mois  spin  
GtkWidget *input75; // heure combobox     
GtkWidget *output55; //msg suc          

input72=lookup_widget(obj,"spinbutton28");
input73=lookup_widget(obj,"spinbutton29");
input74=lookup_widget(obj,"spinbutton30");
input75=lookup_widget(obj,"combobox9");
output55=lookup_widget(obj,"label1414");

ds.dtn.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input72));
ds.dtn.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input73));
ds.dtn.annees=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input74));

if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input75))!=NULL)
{
strcpy(ds.horaire,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input75))); 
}



if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input75))!=NULL)
{
ajout_dispo_med(ds,u);
gtk_label_set_text(GTK_LABEL(output55),"success");
}
if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input75))==NULL)
{gtk_label_set_text(GTK_LABEL(output55),"veuillez remplir tous les champs");
}


}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
void on_button58_clicked (GtkButton *obj,gpointer  user_data)  // ajout dispo diet  
{
dispo1 ds;
GtkWidget *input76; //jour  spin
GtkWidget *input77; //mois  spin
GtkWidget *input78; //mois  spin  
GtkWidget *input79; // heure combobox     
GtkWidget *output56; //msg suc 

input76=lookup_widget(obj,"spinbutton31");
input77=lookup_widget(obj,"spinbutton32");
input78=lookup_widget(obj,"spinbutton33");
input79=lookup_widget(obj,"combobox10");
output56=lookup_widget(obj,"label1425");

ds.dtn.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input76));
ds.dtn.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input77));
ds.dtn.annees=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input78));

if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input79))!=NULL)
{
strcpy(ds.horaire,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input79))); 
}

if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input79))!=NULL)
{
ajout_dispo_diet(ds,u);
gtk_label_set_text(GTK_LABEL(output56),"success");
}

if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input79))==NULL)
{
gtk_label_set_text(GTK_LABEL(output56),"veuillez remplir tous les champs");
}

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
void on_button59_clicked (GtkButton *obj,gpointer  user_data)  // ajout dispo coach  
{
dispo1 ds;
GtkWidget *input80; //jour  spin
GtkWidget *input81; //mois  spin
GtkWidget *input82; //mois  spin  
GtkWidget *input83; // heure combobox     
GtkWidget *output57; //msg suc 

input80=lookup_widget(obj,"spinbutton34");
input81=lookup_widget(obj,"spinbutton35");
input82=lookup_widget(obj,"spinbutton36");
input83=lookup_widget(obj,"combobox11");
output57=lookup_widget(obj,"label1432");

ds.dtn.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input80));
ds.dtn.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input81));
ds.dtn.annees=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input82));

if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input83))!=NULL)
{
strcpy(ds.horaire,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input83))); 
}

if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input83))!=NULL)
{
ajout_dispo_coach(ds,u);
gtk_label_set_text(GTK_LABEL(output57),"success");
}

if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input83))==NULL)
{
gtk_label_set_text(GTK_LABEL(output57),"veuillez remplir tous les champs");
}

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////
void on_button60_clicked (GtkButton *obj,gpointer  user_data) // ajout dispo kine  
{
dispo1 ds;
GtkWidget *input84; //jour  spin
GtkWidget *input85; //mois  spin
GtkWidget *input86; //mois  spin  
GtkWidget *input87; // heure combobox     
GtkWidget *output58; //msg suc 

input84=lookup_widget(obj,"spinbutton37");
input85=lookup_widget(obj,"spinbutton38");
input86=lookup_widget(obj,"spinbutton39");
input87=lookup_widget(obj,"combobox12");
output58=lookup_widget(obj,"label1438");
ds.dtn.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input84));
ds.dtn.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input85));
ds.dtn.annees=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input86));

if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input87))!=NULL)
{
strcpy(ds.horaire,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input87))); 
}

if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input87))!=NULL)
{
ajout_dispo_kine(ds,u);
gtk_label_set_text(GTK_LABEL(output58),"success");
}

if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input87))==NULL)
{
gtk_label_set_text(GTK_LABEL(output58),"veuillez remplir tous les champs");
}

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void on_button64_clicked (GtkWidget *obj,gpointer user_data)
{
event e;
	GtkWidget *input100; //titre
	GtkWidget *input101; //jour
	GtkWidget *input102; //mois
	GtkWidget *input103; //année     
	GtkWidget *input104; //description 

	input100=lookup_widget(obj,"entry242");
	input101=lookup_widget(obj,"spinbutton40");
	input102=lookup_widget(obj,"spinbutton41");
	input103=lookup_widget(obj,"spinbutton42");
	input104=lookup_widget(obj,"entry243");

	e.dtn.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input101));
	e.dtn.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input102));
	e.dtn.annees=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input103));

	strcpy(e.titre,gtk_entry_get_text(GTK_ENTRY(input100)));
	strcpy(e.description,gtk_entry_get_text(GTK_ENTRY(input104)));
	ajouter_eve(e);
}




