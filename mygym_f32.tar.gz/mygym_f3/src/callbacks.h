#include <gtk/gtk.h>


void on_button1_clicked (GtkWidget *obj, gpointer user_data);
void on_logout1_clicked (GtkButton *obj, gpointer user_data);
void on_logout2_clicked (GtkButton *obj, gpointer user_data);
void on_logout3_clicked (GtkButton *obj, gpointer user_data);
void on_logout4_clicked (GtkButton *obj, gpointer user_data);
void on_logout5_clicked (GtkButton *obj, gpointer user_data);
void on_logout6_clicked (GtkButton *obj, gpointer user_data);

void on_Admin_set_focus (GtkWindow *window,GtkWidget *widget,gpointer user_data);
void on_Adh__rent_set_focus(GtkWindow *window,GtkWidget *widget,gpointer user_data);
void on_Coach_set_focus(GtkWindow *window,GtkWidget *widget,gpointer user_data);
void on_Medecin_set_focus(GtkWindow *window,GtkWidget *widget,gpointer user_data);
void on_Kin___set_focus(GtkWindow *window,GtkWidget *widget,gpointer user_data);
void on_Dieteticien_set_focus(GtkWindow *window,GtkWidget *widget,gpointer user_data);


void on_button48_clicked(GtkButton *obj, gpointer user_data); //modifier login et mot de passe medicin 
void on_button49_clicked(GtkButton *obj, gpointer user_data); //modier login et mot de passe diet
void on_button50_clicked(GtkButton *obj, gpointer user_data); //modier login et mot de passe kine
void on_button9_clicked(GtkButton *obj, gpointer user_data); //modier login et mot de passe Admin
void on_button46_clicked(GtkButton *obj, gpointer user_data); //modier login et mot de passe Adherant 
void on_button47_clicked(GtkButton *obj, gpointer user_data); //modier login et mot de passe Adherant 


void on_treeview12_row_activated(GtkTreeView *treeview,GtkTreePath *path,GtkTreeViewColumn *column,gpointer user_data);//treeview espace adherent



void on_treeview9_row_activated(GtkTreeView *treeview,GtkTreePath *path,GtkTreeViewColumn *column,gpointer user_data);//treeview espace admin-->medicin
void on_button43_clicked(GtkWidget *obj, gpointer user_data);  	//ajout med
void on_button16_clicked(GtkWidget *obj, gpointer user_data);	//sauvegarder
void on_button17_clicked(GtkWidget *obj, gpointer user_data);	//quitter
void on_button45_clicked (GtkButton *obj, gpointer user_data);	// suprimer medicin 
void on_button44_clicked (GtkButton *obj, gpointer user_data);	// Modifier medicin 
void on_Ajout_medcin_set_focus (GtkWindow *window, GtkWidget *widget,gpointer user_data); // set focus modif medicin



void on_treeview5_row_activated(GtkTreeView *treeview,GtkTreePath *path,GtkTreeViewColumn *column,gpointer user_data);//treeview espace admin-->adherant
void on_button32_clicked (GtkButton *obj, gpointer user_data);	// Modifier adhernat 
void on_button33_clicked (GtkButton *obj, gpointer user_data);	// supprimer adhernat 
void on_button31_clicked(GtkWidget *obj, gpointer user_data);  //ajout adh
void on_button12_clicked(GtkWidget *obj, gpointer user_data);  //sauvegarder 
void on_button11_clicked(GtkWidget *obj, gpointer user_data); //quitter
void on_Ajout_Adh__rent_set_focus (GtkWindow *window, GtkWidget *widget, gpointer  user_data);//set focus modif adherant 
 




void on_button54_clicked (GtkButton  *obj,gpointer  user_data); //select staff to view fo adherant 
void on_dispo_set_focus (GtkWindow *window,GtkWidget *widget,gpointer user_data); // set focus fenetre dispo 
void on_button55_clicked (GtkButton  *obj,gpointer  user_data); //quitter fenetre dsipo 
void on_button56_clicked (GtkButton *obj,gpointer  user_data);  // confirmer rdv 


void on_button57_clicked (GtkButton *obj,gpointer  user_data);  // ajout dispo medicin  
void on_button58_clicked (GtkButton *obj,gpointer  user_data);  // ajout dispo diet  
void on_button59_clicked (GtkButton *obj,gpointer  user_data);  // ajout dispo coach  
void on_button60_clicked (GtkButton *obj,gpointer  user_data);  // ajout dispo kine  



void on_treeview8_row_activated(GtkTreeView *treeview, GtkTreePath *path,GtkTreeViewColumn *column,gpointer user_data);//treeview espace admin-->kine
void on_button41_clicked(GtkButton  *obj, gpointer user_data); // modifier coordoners kine 
void on_button42_clicked (GtkButton  *obj,gpointer user_data); // supprumer kine 
void on_button40_clicked(GtkWidget *obj, gpointer user_data); //ajout kine 
void on_button19_clicked(GtkWidget *obj, gpointer user_data); //sauvegarder
void on_button18_clicked(GtkWidget *obj, gpointer user_data); //quitter
void on_Ajout_kin___set_focus(GtkWindow  *window,GtkWidget *widget,gpointer  user_data);//set focus modif kine


void on_treeview7_row_activated(GtkTreeView *treeview, GtkTreePath *path,GtkTreeViewColumn *column,gpointer user_data);//treeview espace admin-->kine
void on_button38_clicked(GtkButton  *obj, gpointer user_data); // modifier coordoners diet 
void on_button39_clicked(GtkButton  *obj, gpointer user_data); // supprimer  diet 
void on_button37_clicked (GtkWidget *obj, gpointer user_data); //ajout diet
void on_button20_clicked (GtkButton *obj, gpointer user_data); // sauvegarder
void on_button21_clicked (GtkButton *obj, gpointer user_data);//quitter la fenetre
void on_Ajout_dieteticien_set_focus(GtkWindow  *window, GtkWidget *widget,gpointer user_data);//set focus 


void on_button35_clicked(GtkWidget *obj, gpointer user_data); //modifier coach 
void on_button36_clicked(GtkWidget *obj, gpointer user_data); //supprimer coach 
void on_button34_clicked(GtkWidget *obj, gpointer user_data); //ajout coach 
void on_button13_clicked(GtkWidget *obj, gpointer user_data); //sauvegarder
void on_button14_clicked(GtkWidget *obj, gpointer user_data); //quitter
void on_Ajout_coach_set_focus(GtkWindow  *window, GtkWidget *widget,gpointer user_data);//set focus
void on_treeview6_row_activated(GtkTreeView *treeview,GtkTreePath*path,GtkTreeViewColumn *column, gpointer user_data);//treeview espace admin-->coach



void on_treeview1_row_activated(GtkTreeView *treeview,GtkTreePath*path,GtkTreeViewColumn *column, gpointer user_data);//treeview espace medicin-->fichemidical
void on_button51_clicked (GtkButton *obj,gpointer  user_data); //ajout fiche medicale
void on_button23_clicked (GtkButton *obj,gpointer  user_data); // sauvgarder
void on_button22_clicked (GtkButton *obj,gpointer  user_data); //quitter
void on_button52_clicked(GtkWidget *obj, gpointer user_data); //modifier fich medical 
void on_button53_clicked(GtkWidget *obj, gpointer user_data); //supprimer fiche fich medical 
void on_fiche_med_set_focus(GtkWindow  *window,GtkWidget  *widget,gpointer user_data);//set focus
void on_button62_clicked (GtkButton *obj,gpointer  user_data); // afficher fiche 
void on_button61_clicked (GtkButton *obj,gpointer  user_data); // quitter  window fiche 
void on_window1_set_focus (GtkWindow  *window,GtkWidget  *widget,gpointer user_data);//set focus fiche medicale 
void on_button63_clicked (GtkButton *obj,gpointer  user_data); // afficher fiche  depuis diet 
void on_treeview4_row_activated(GtkTreeView *treeview,GtkTreePath*path,GtkTreeViewColumn *column, gpointer user_data);//treeview espace fiche --> diet





